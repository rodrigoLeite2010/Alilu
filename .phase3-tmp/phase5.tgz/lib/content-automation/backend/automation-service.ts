import "server-only";
import { canUseAiAutomation } from "@/lib/billing/backend/automation-access-service";
import { isValidTimeZone } from "@/lib/instagram/schedule-time";
import { isPostTemplateId } from "@/lib/instagram/templates";
import { isValidHexColor } from "@/lib/instagram/colors";
import { getInstagramAccountByIdForUser } from "@/lib/instagram/backend/instagram-account-repository";
import { getInstagramMediaById } from "@/lib/instagram/backend/media-repository";
import {
  cancelPost,
  InstagramPostValidationError,
  reschedulePost,
} from "@/lib/instagram/backend/instagram-post-service";
import {
  createAutomation as createAutomationInDb,
  deleteAutomation as deleteAutomationInDb,
  duplicateAutomation as duplicateAutomationInDb,
  getAutomationForUser,
  listAutomationsForUser as listAutomationsForUserInDb,
  setAutomationStatus,
  updateAutomation as updateAutomationInDb,
  updateAutomationDay as updateAutomationDayInDb,
  addAutomationSlot as addAutomationSlotInDb,
  replaceSharedSchedule as replaceSharedScheduleInDb,
  setScheduleMode as setScheduleModeInDb,
  updateSharedConfig as updateSharedConfigInDb,
  removeAutomationSlot as removeAutomationSlotInDb,
  AutomationSlotLimitError,
  type AutomationDayRef,
  type AutomationListItem,
  type UpdateAutomationDayInput,
  type UpdateAutomationInput,
  updateSmartStoryConfig as updateSmartStoryConfigInDb,
  updateSmartCarouselConfig as updateSmartCarouselConfigInDb,
} from "./automation-repository";
import {
  cancelPendingRunsForAutomation,
  getRunOwnedByUser,
  listRunsForAutomationOwnedByUser,
  listRunHistoryForAutomationOwnedByUser,
  listRecentRunsForUser,
  setRunStatus,
  setRunPublication,
  resetRunForRegeneration,
} from "./automation-run-repository";
import { generateSmartCarouselPreview, type SmartCarouselPreviewResult, type SmartCarouselRunDeps } from "./smart-carousel-service";
import { CarouselError } from "@/lib/carousel/backend/carousel-project-service";
import { publishCarousel } from "@/lib/carousel/backend/carousel-publish-service";
import { detachProjectFromAutomationRun, getProjectByAutomationRun } from "@/lib/carousel/backend/carousel-repository";
import { findNextSlot, publishInstantUtc, zonedToday } from "./automation-time";
import { normalizeSmartStoryConfig, validateSmartStoryConfigInput } from "../smart-story/config";
import { normalizeSmartCarouselConfig, validateSmartCarouselConfigInput, type SmartCarouselConfig } from "../smart-carousel/config";
import {
  effectiveDays,
  SharedScheduleError,
  validateSharedSchedule,
} from "../shared-schedule";
import {
  CONTENT_CATEGORIES,
  DAY_OF_WEEK_LABEL,
  DAYS_OF_WEEK,
  SCHEDULE_MODES,
  MAX_VISUAL_TEXT_LENGTH,
  MAX_CAROUSEL_VISUAL_TEXT_LENGTH,
  type AutomationContentCategory,
  type AutomationContentMode,
  type AutomationContentType,
  type AutomationDayRecord,
  type AutomationScheduleMode,
  type AutomationSharedConfig,
  type AutomationWithDays,
  type DayOfWeek,
  type ImageMode,
  type VideoSelection,
} from "./automation-types";

/**
 * Validação e regras de negócio do Piloto Automático de Conteúdo — nunca
 * confia em nada vindo do cliente sem checar posse (conta, mídia) e
 * formato, mesmo padrão de instagram-post-service.ts.
 *
 * Restrições desta etapa (ver docs/content-automation.md):
 * imageMode aceita FIXED_IMAGE/MEDIA_LIBRARY/AUTO_TEMPLATE (este último
 * renderiza o texto visual — IA ou manual — sobre a imagem escolhida no
 * servidor, ver template-render-service.ts) e videoSelection só aceita
 * FIXED (ROTATE/RANDOM ficam para uma etapa futura). O schema já reserva
 * os outros valores de videoSelection para não exigir migração quando
 * isso for implementado.
 */

export class AutomationValidationError extends Error {
  /** Código de plano (ex.: "AI_PLAN_REQUIRED") quando o bloqueio é comercial — a tela mostra o convite de upgrade por ele. */
  code?: string;
  constructor(message: string, code?: string) {
    super(message);
    this.name = "AutomationValidationError";
    this.code = code;
  }
}

/** Texto de IA só em plano com IA (ou no teste gratuito) — o servidor decide, nunca a tela. */
async function assertPlanAllowsAi(userId: string): Promise<void> {
  const access = await canUseAiAutomation(userId);
  if (!access.allowed) {
    throw new AutomationValidationError(access.reason ?? "Seu plano não inclui geração com IA.", access.code ?? "AI_PLAN_REQUIRED");
  }
}

const SUPPORTED_IMAGE_MODES: ImageMode[] = ["FIXED_IMAGE", "MEDIA_LIBRARY", "AUTO_TEMPLATE"];
const SUPPORTED_VIDEO_SELECTIONS: VideoSelection[] = ["FIXED"];
const MAX_NAME_LENGTH = 120;
const MAX_BRAND_CONTEXT_LENGTH = 2000;
const MAX_PROMPT_LENGTH = 800;
/** Mesmo limite de legenda da Meta usado em todo o resto do projeto (ver instagram-post-service.ts). */
const MAX_MANUAL_CAPTION_LENGTH = 2200;
// MAX_VISUAL_TEXT_LENGTH e MAX_CAROUSEL_VISUAL_TEXT_LENGTH agora vêm de
// automation-types.ts — compartilhados com o formulário (WeekDayEditor),
// que não pode importar este módulo "server-only".
/** Mesmos níveis de AUTO_TEMPLATE_OVERLAY_LEVELS (template-render-service.ts) — duplicado aqui só como literal para não puxar @napi-rs/canvas nesta camada de validação. */
const ALLOWED_OVERLAY_OPACITY_LEVELS = [0, 0.1, 0.2, 0.3, 0.4];
const PUBLISH_TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

function assertName(name: string): string {
  const trimmed = name.trim();
  if (!trimmed) throw new AutomationValidationError("Dê um nome para a automação.");
  if (trimmed.length > MAX_NAME_LENGTH) throw new AutomationValidationError(`O nome pode ter no máximo ${MAX_NAME_LENGTH} caracteres.`);
  return trimmed;
}

function assertTimezone(timezone: string): string {
  if (!isValidTimeZone(timezone)) throw new AutomationValidationError("Fuso horário inválido.");
  return timezone;
}

function assertImageMode(imageMode: ImageMode): ImageMode {
  if (!SUPPORTED_IMAGE_MODES.includes(imageMode)) {
    throw new AutomationValidationError('Modo de imagem inválido.');
  }
  return imageMode;
}

function assertVideoSelection(videoSelection: VideoSelection): VideoSelection {
  if (!SUPPORTED_VIDEO_SELECTIONS.includes(videoSelection)) {
    throw new AutomationValidationError('Só "Vídeo fixo" está disponível nesta etapa para Reels.');
  }
  return videoSelection;
}

async function assertOwnedImageMedia(mediaId: string | null, userId: string): Promise<string | null> {
  if (!mediaId) return null;
  const media = await getInstagramMediaById(mediaId, userId);
  if (!media || media.mediaType !== "image") {
    throw new AutomationValidationError("Imagem selecionada não foi encontrada ou não é uma imagem.");
  }
  return media.id;
}

async function assertOwnedVideoMedia(mediaId: string | null, userId: string): Promise<string | null> {
  if (!mediaId) return null;
  const media = await getInstagramMediaById(mediaId, userId);
  if (!media || media.mediaType !== "video") {
    throw new AutomationValidationError("Vídeo selecionado não foi encontrado ou não é um vídeo.");
  }
  return media.id;
}

export interface CreateAutomationServiceInput {
  userId: string;
  instagramAccountId: string;
  name: string;
  description?: string;
  timezone?: string;
  brandContext?: string;
  autoPublish?: boolean;
  requireApproval?: boolean;
  generationLeadMinutes?: number;
  imageMode?: ImageMode;
  fixedImageMediaId?: string | null;
  videoSelection?: VideoSelection;
  fixedVideoMediaId?: string | null;
  /** "CUSTOM" (padrão) ou "SHARED_PROMPT" ("Prompt único recorrente"). */
  scheduleMode?: AutomationScheduleMode;
}

function assertScheduleMode(mode: unknown): AutomationScheduleMode {
  if (typeof mode !== "string" || !SCHEDULE_MODES.includes(mode as AutomationScheduleMode)) {
    throw new AutomationValidationError("Modo de configuração inválido.");
  }
  return mode as AutomationScheduleMode;
}

export async function createAutomation(input: CreateAutomationServiceInput): Promise<string> {
  const account = await getInstagramAccountByIdForUser(input.instagramAccountId, input.userId);
  if (!account) {
    throw new AutomationValidationError("Conta do Instagram não encontrada ou não conectada por você.");
  }

  const name = assertName(input.name);
  const timezone = assertTimezone(input.timezone ?? "America/Sao_Paulo");
  const imageMode = assertImageMode(input.imageMode ?? "FIXED_IMAGE");
  const videoSelection = assertVideoSelection(input.videoSelection ?? "FIXED");
  const fixedImageMediaId = await assertOwnedImageMedia(input.fixedImageMediaId ?? null, input.userId);
  const fixedVideoMediaId = await assertOwnedVideoMedia(input.fixedVideoMediaId ?? null, input.userId);
  const generationLeadMinutes = Math.max(0, Math.min(1440, input.generationLeadMinutes ?? 120));

  const requireApproval = input.requireApproval ?? true;
  const autoPublish = requireApproval ? false : (input.autoPublish ?? false);
  const scheduleMode = input.scheduleMode === undefined ? "CUSTOM" : assertScheduleMode(input.scheduleMode);

  return createAutomationInDb({
    scheduleMode,
    userId: input.userId,
    instagramAccountId: account.id,
    name,
    description: (input.description ?? "").trim().slice(0, 500),
    timezone,
    brandContext: (input.brandContext ?? "").trim().slice(0, MAX_BRAND_CONTEXT_LENGTH),
    autoPublish,
    requireApproval,
    generationLeadMinutes,
    imageMode,
    fixedImageMediaId,
    videoSelection,
    fixedVideoMediaId,
  });
}

export async function getAutomationDetails(id: string, userId: string): Promise<AutomationWithDays> {
  const automation = await getAutomationForUser(id, userId);
  if (!automation) throw new AutomationValidationError("Automação não encontrada.");
  return automation;
}

export async function listAutomations(userId: string): Promise<AutomationListItem[]> {
  return listAutomationsForUserInDb(userId);
}

export type UpdateAutomationServiceInput = Partial<CreateAutomationServiceInput>;

export async function updateAutomation(
  id: string,
  userId: string,
  input: UpdateAutomationServiceInput,
): Promise<void> {
  const current = await getAutomationDetails(id, userId);

  const patch: UpdateAutomationInput = {};
  if (input.name !== undefined) patch.name = assertName(input.name);
  if (input.description !== undefined) patch.description = input.description.trim().slice(0, 500);
  if (input.timezone !== undefined) patch.timezone = assertTimezone(input.timezone);
  if (input.brandContext !== undefined) patch.brandContext = input.brandContext.trim().slice(0, MAX_BRAND_CONTEXT_LENGTH);
  if (input.generationLeadMinutes !== undefined) patch.generationLeadMinutes = Math.max(0, Math.min(1440, input.generationLeadMinutes));
  if (input.imageMode !== undefined) patch.imageMode = assertImageMode(input.imageMode);
  if (input.videoSelection !== undefined) patch.videoSelection = assertVideoSelection(input.videoSelection);
  if (input.fixedImageMediaId !== undefined) patch.fixedImageMediaId = await assertOwnedImageMedia(input.fixedImageMediaId, userId);
  if (input.fixedVideoMediaId !== undefined) patch.fixedVideoMediaId = await assertOwnedVideoMedia(input.fixedVideoMediaId, userId);
  if (input.instagramAccountId !== undefined) {
    const account = await getInstagramAccountByIdForUser(input.instagramAccountId, userId);
    if (!account) throw new AutomationValidationError("Conta do Instagram não encontrada ou não conectada por você.");
    patch.instagramAccountId = account.id;
  }

  const requireApproval = input.requireApproval ?? current.requireApproval;
  patch.requireApproval = requireApproval;
  patch.autoPublish = requireApproval ? false : (input.autoPublish ?? current.autoPublish);

  let modeChange: AutomationScheduleMode | null = null;
  if (input.scheduleMode !== undefined) {
    const mode = assertScheduleMode(input.scheduleMode);
    if (mode !== current.scheduleMode) {
      if (current.status === "ACTIVE") {
        throw new AutomationValidationError("Pause a automação antes de trocar o modo de configuração.");
      }
      modeChange = mode;
    }
  }

  const updated = await updateAutomationInDb(id, userId, patch);
  if (!updated) throw new AutomationValidationError("Automação não encontrada.");
  if (modeChange) await setScheduleModeInDb(id, userId, modeChange);
}

const SUPPORTED_CONTENT_TYPES: AutomationContentType[] = ["POST", "REEL", "CAROUSEL", "STORY", "SMART_CAROUSEL"];

/** Campos de conteúdo (iguais em uma linha de dia/horário e no conteúdo compartilhado). */
type ContentFieldsInput = Pick<
  UpdateDayServiceInput,
  | "contentType"
  | "contentCategory"
  | "contentMode"
  | "prompt"
  | "manualCaption"
  | "visualText"
  | "templateId"
  | "styleConfig"
  | "overlayOpacity"
  | "visualTextColor"
  | "imageMediaId"
  | "videoMediaId"
>;

/**
 * Valida os campos de conteúdo e devolve só o que veio no input — usado
 * tanto por updateAutomationDay (modo CUSTOM) quanto por
 * updateSharedAutomation (modo "Prompt único recorrente"), para as duas
 * telas terem EXATAMENTE as mesmas regras.
 */
async function buildContentPatch(userId: string, input: ContentFieldsInput): Promise<Partial<AutomationSharedConfig>> {
  const patch: Partial<AutomationSharedConfig> = {};
  if (input.contentType !== undefined) {
    if (!SUPPORTED_CONTENT_TYPES.includes(input.contentType)) {
      throw new AutomationValidationError("Tipo de conteúdo inválido.");
    }
    patch.contentType = input.contentType;
  }
  if (input.contentCategory !== undefined) {
    if (input.contentCategory !== null && !CONTENT_CATEGORIES.includes(input.contentCategory)) {
      throw new AutomationValidationError("Categoria inválida.");
    }
    patch.contentCategory = input.contentCategory;
  }
  if (input.contentMode !== undefined) {
    if (input.contentMode === "AI" && input.contentType !== "SMART_CAROUSEL") await assertPlanAllowsAi(userId);
    patch.contentMode = input.contentMode;
  }
  if (input.prompt !== undefined) {
    const trimmed = input.prompt.trim();
    if (trimmed.length > MAX_PROMPT_LENGTH) {
      throw new AutomationValidationError(`O prompt do dia pode ter no máximo ${MAX_PROMPT_LENGTH} caracteres.`);
    }
    patch.prompt = trimmed;
  }
  if (input.manualCaption !== undefined) {
    const trimmed = input.manualCaption === null ? null : input.manualCaption.trim();
    if (trimmed && trimmed.length > MAX_MANUAL_CAPTION_LENGTH) {
      throw new AutomationValidationError(`A legenda manual pode ter no máximo ${MAX_MANUAL_CAPTION_LENGTH} caracteres.`);
    }
    patch.manualCaption = trimmed;
  }
  if (input.visualText !== undefined) {
    const trimmed = input.visualText === null ? null : input.visualText.trim();
    // CAROUSEL divide o texto em vários slides (generateSlidesFromText),
    // então aceita um texto bem mais longo que POST (uma imagem só). O
    // patch sempre chega com os dois campos juntos nesta tela (ver
    // AutomationEditor.tsx/AutomationWizard.tsx — salvam o dia inteiro de
    // uma vez), então input.contentType já reflete o tipo efetivo deste
    // dia quando visualText também está sendo validado.
    const effectiveMaxLength = input.contentType === "CAROUSEL" ? MAX_CAROUSEL_VISUAL_TEXT_LENGTH : MAX_VISUAL_TEXT_LENGTH;
    if (trimmed && trimmed.length > effectiveMaxLength) {
      throw new AutomationValidationError(`O texto sobre a imagem pode ter no máximo ${effectiveMaxLength} caracteres.`);
    }
    patch.visualText = trimmed;
  }
  if (input.templateId !== undefined) {
    if (input.templateId !== null && !isPostTemplateId(input.templateId)) {
      throw new AutomationValidationError("Template inválido.");
    }
    patch.templateId = input.templateId;
  }
  if (input.styleConfig !== undefined) {
    if (input.styleConfig !== null && (typeof input.styleConfig !== "object" || Array.isArray(input.styleConfig))) {
      throw new AutomationValidationError("Configuração de estilo inválida.");
    }
    patch.styleConfig = input.styleConfig;
  }
  if (input.overlayOpacity !== undefined) {
    if (input.overlayOpacity !== null && !ALLOWED_OVERLAY_OPACITY_LEVELS.includes(input.overlayOpacity)) {
      throw new AutomationValidationError("Nível de véu sobre a imagem inválido.");
    }
    patch.overlayOpacity = input.overlayOpacity;
  }
  if (input.visualTextColor !== undefined) {
    if (input.visualTextColor !== null && !isValidHexColor(input.visualTextColor)) {
      throw new AutomationValidationError("Cor do texto inválida — use um código hexadecimal (ex.: #ffffff).");
    }
    patch.visualTextColor = input.visualTextColor;
  }
  if (input.imageMediaId !== undefined) patch.imageMediaId = await assertOwnedImageMedia(input.imageMediaId, userId);
  if (input.videoMediaId !== undefined) patch.videoMediaId = await assertOwnedVideoMedia(input.videoMediaId, userId);

  return patch;
}

export interface UpdateDayServiceInput {
  enabled?: boolean;
  /** Categoria opcional do horário (Motivacional, Financeiro…) — só alimenta {{categoria}} e a sugestão de prompt. */
  contentCategory?: AutomationContentCategory | null;
  contentType?: AutomationContentType;
  contentMode?: AutomationContentMode;
  prompt?: string;
  manualCaption?: string | null;
  /** Texto curto para desenhar sobre a imagem quando imageMode = "AUTO_TEMPLATE" e contentMode = "MANUAL". */
  visualText?: string | null;
  publishTime?: string;
  /** Template do compositor (ver lib/instagram/templates.ts) usado quando imageMode = "AUTO_TEMPLATE". null/ausente usa o template padrão. */
  templateId?: string | null;
  /** Estado serializado do editor (mesmo formato de serializeEditorState) — cores/fontes do template; o texto visual é sempre injetado por cima na hora de renderizar. */
  styleConfig?: Record<string, unknown> | null;
  /** Véu (0/0.1/0.2/0.3/0.4) sobre a foto quando imageMode = "AUTO_TEMPLATE". null usa o padrão (20%). */
  overlayOpacity?: number | null;
  /** Cor (hex "#rrggbb") do texto sobre a imagem quando imageMode = "AUTO_TEMPLATE". null usa o padrão (branco). */
  visualTextColor?: string | null;
  imageMediaId?: string | null;
  videoMediaId?: string | null;
}

/**
 * No modo "Prompt único recorrente" as linhas de dia/horário são geridas
 * pela agenda (updateSharedAutomation): editar uma delas à mão a faria
 * divergir da agenda e do conteúdo compartilhado.
 */
async function assertCustomScheduleMode(automationId: string, userId: string): Promise<void> {
  const automation = await getAutomationDetails(automationId, userId);
  if (automation.scheduleMode === "SHARED_PROMPT") {
    throw new AutomationValidationError(
      'Esta automação usa o modo "Prompt único recorrente": edite o prompt, os dias e os horários pelo formulário dela.',
    );
  }
}

export async function updateAutomationDay(
  automationId: string,
  userId: string,
  dayRef: AutomationDayRef,
  input: UpdateDayServiceInput,
): Promise<void> {
  await assertCustomScheduleMode(automationId, userId);
  // dayRef: um dia da semana (= o horário principal dele, comportamento de
  // sempre) ou { slotId } (qualquer horário, inclusive os extras do dia).
  if (typeof dayRef === "string" && !DAYS_OF_WEEK.includes(dayRef)) {
    throw new AutomationValidationError("Dia da semana inválido.");
  }

  const patch: UpdateAutomationDayInput = {};
  if (input.enabled !== undefined) patch.enabled = input.enabled;
  Object.assign(patch, await buildContentPatch(userId, input));
  if (input.publishTime !== undefined) {
    if (!PUBLISH_TIME_RE.test(input.publishTime)) throw new AutomationValidationError("Horário inválido (use HH:mm).");
    patch.publishTime = input.publishTime;
  }
  const updated = await updateAutomationDayInDb(automationId, userId, dayRef, patch);
  if (!updated) throw new AutomationValidationError("Automação ou dia não encontrado.");
}

export interface UpdateSharedServiceInput {
  /** Conteúdo compartilhado (parcial: o que não vier é mantido). */
  content?: ContentFieldsInput;
  /** Agenda completa desejada (dias × horários). Substitui a agenda atual. */
  schedule?: { days: unknown; times: unknown };
}

/**
 * Salva o modo "Prompt único recorrente": conteúdo compartilhado (UMA vez,
 * vale para todas as execuções futuras) e/ou agenda (dias × horários).
 * Valida TUDO antes de gravar qualquer coisa. Devolve quantas execuções
 * por semana a agenda gera (null se a agenda não foi alterada).
 */
export async function updateSharedAutomation(
  id: string,
  userId: string,
  input: UpdateSharedServiceInput,
): Promise<number | null> {
  const current = await getAutomationDetails(id, userId);
  if (current.scheduleMode !== "SHARED_PROMPT") {
    throw new AutomationValidationError('Esta automação não usa o modo "Prompt único recorrente".');
  }

  let schedule: ReturnType<typeof validateSharedSchedule> | null = null;
  if (input.schedule !== undefined) {
    try {
      schedule = validateSharedSchedule(input.schedule);
    } catch (error) {
      if (error instanceof SharedScheduleError) throw new AutomationValidationError(error.message);
      throw error;
    }
  }

  let contentPatch: Partial<AutomationSharedConfig> | null = null;
  if (input.content !== undefined) {
    // O limite do texto visual depende do tipo efetivo (carrossel é maior).
    contentPatch = await buildContentPatch(userId, {
      ...input.content,
      contentType: input.content.contentType ?? current.shared.contentType,
    });
  }

  // Automação ATIVA nunca pode ficar com conteúdo incompleto.
  if (current.status === "ACTIVE" && contentPatch) {
    const probe = current.days[0];
    if (probe) {
      assertReadyToActivate({
        ...current,
        shared: { ...current.shared, ...contentPatch },
        days: effectiveDays({ ...current, shared: { ...current.shared, ...contentPatch }, days: [{ ...probe, enabled: true }] }),
      });
    }
  }

  if (contentPatch) {
    const updated = await updateSharedConfigInDb(id, userId, contentPatch);
    if (!updated) throw new AutomationValidationError("Automação não encontrada.");
  }
  if (!schedule) return null;
  const weekly = await replaceSharedScheduleInDb(id, userId, schedule);
  if (weekly === null) throw new AutomationValidationError("Automação não encontrada.");
  return weekly;
}

export interface UpdateSmartStoryServiceInput {
  /** Liga/desliga o modo inteligente de Stories (omitido = mantém). */
  enabled?: boolean;
  /** Configuração parcial (o que não vier é mantido). Valor inválido é ERRO, nunca trocado em silêncio. */
  config?: unknown;
}

/**
 * Salva o "Modo inteligente de Stories". Só mexe na flag e na configuração:
 * dias, horários, conteúdo e execuções ficam como estão — e, desligado, os
 * Stories saem exatamente como antes. Devolve a configuração salva.
 */
export async function updateSmartStory(
  id: string,
  userId: string,
  input: UpdateSmartStoryServiceInput,
): Promise<{ enabled: boolean; config: ReturnType<typeof normalizeSmartStoryConfig> }> {
  const current = await getAutomationDetails(id, userId);
  if (input.enabled !== undefined && typeof input.enabled !== "boolean") {
    throw new AutomationValidationError("enabled precisa ser verdadeiro ou falso.");
  }
  if (input.config !== undefined) {
    const problems = validateSmartStoryConfigInput(input.config);
    if (problems.length > 0) throw new AutomationValidationError(problems.join(" "));
  }
  const enabled = input.enabled ?? current.smartStory.enabled;
  const config = normalizeSmartStoryConfig(
    input.config === undefined ? current.smartStory.config : { ...current.smartStory.config, ...(input.config as Record<string, unknown>) },
    enabled,
  );
  const updated = await updateSmartStoryConfigInDb(id, userId, { enabled, config });
  if (!updated) throw new AutomationValidationError("Automação não encontrada.");
  return { enabled, config };
}

export interface UpdateSmartCarouselServiceInput {
  /** Configuração parcial (o que não vier é mantido). Valor inválido é ERRO. */
  config?: unknown;
}

/** Salva a configuração do Carrossel Inteligente automático. Só mexe nela. */
export async function updateSmartCarousel(id: string, userId: string, input: UpdateSmartCarouselServiceInput): Promise<SmartCarouselConfig> {
  const current = await getAutomationDetails(id, userId);
  if (input.config !== undefined) {
    const problems = validateSmartCarouselConfigInput(input.config);
    if (problems.length > 0) throw new AutomationValidationError(problems.join(" "));
  }
  const config = normalizeSmartCarouselConfig(
    input.config === undefined ? current.smartCarousel : { ...current.smartCarousel, ...(input.config as Record<string, unknown>) },
  );
  const updated = await updateSmartCarouselConfigInDb(id, userId, config);
  if (!updated) throw new AutomationValidationError("Automação não encontrada.");
  return config;
}

/** "+ Adicionar horário" num dia da semana. Devolve o id do novo horário. */
export async function addAutomationSlot(automationId: string, userId: string, dayOfWeek: DayOfWeek): Promise<string> {
  if (!DAYS_OF_WEEK.includes(dayOfWeek)) throw new AutomationValidationError("Dia da semana inválido.");
  await assertCustomScheduleMode(automationId, userId);
  try {
    const slotId = await addAutomationSlotInDb(automationId, userId, dayOfWeek);
    if (!slotId) throw new AutomationValidationError("Automação não encontrada.");
    return slotId;
  } catch (error) {
    if (error instanceof AutomationSlotLimitError) throw new AutomationValidationError(error.message);
    throw error;
  }
}

/** Remove um horário extra (o principal de cada dia não pode ser removido — só desabilitado). */
export async function removeAutomationSlot(automationId: string, userId: string, slotId: string): Promise<void> {
  await assertCustomScheduleMode(automationId, userId);
  const removed = await removeAutomationSlotInDb(automationId, userId, slotId);
  if (!removed) {
    throw new AutomationValidationError("Horário não encontrado — o horário principal do dia não pode ser removido, só desativado.");
  }
}

/** Rótulo de um horário nas mensagens de validação — "segunda-feira às 12:00". */
function slotLabel(day: AutomationDayRecord): string {
  return `${DAY_OF_WEEK_LABEL[day.dayOfWeek].toLowerCase()} às ${day.publishTime}`;
}

/**
 * Valida que a automação está pronta para rodar sozinha antes de deixar
 * ativar: todo dia habilitado precisa de prompt e de uma mídia resolvível
 * — evita descobrir isso só quando o cron falhar de madrugada.
 */
function assertReadyToActivate(automation: AutomationWithDays): void {
  const enabledDays = automation.days.filter((day) => day.enabled);
  if (enabledDays.length === 0) {
    throw new AutomationValidationError("Habilite pelo menos um dia da semana antes de ativar.");
  }
  for (const day of enabledDays) {
    if (day.contentType === "STORY") {
      // Story: texto opcional no modo manual (vazio = só a foto); no modo
      // IA, precisa do prompt. Sempre precisa de uma imagem de fundo.
      if (automation.smartStory.enabled) {
        // Modo inteligente: o motor escolhe tipo, tema, template e fundo. Só
        // precisa do prompt base — imagem fixa/biblioteca/foto do dia (mesmo
        // salvas) são ignoradas.
        if (!day.prompt.trim()) {
          throw new AutomationValidationError(`Defina o prompt base dos Stories inteligentes (${slotLabel(day)}) antes de ativar.`);
        }
        continue;
      }
      if (day.contentMode !== "MANUAL" && !day.prompt.trim()) {
        throw new AutomationValidationError(`Defina o que o Story de ${slotLabel(day)} deve dizer antes de ativar.`);
      }
      if (!(day.imageMediaId ?? automation.fixedImageMediaId)) {
        throw new AutomationValidationError(`Defina uma imagem de fundo para o Story de ${slotLabel(day)}.`);
      }
      continue;
    }
    if (day.contentType === "SMART_CAROUSEL") {
      // O motor escolhe imagens, template e texto: precisa só de um tema (prompt) OU de uma categoria.
      if (!day.prompt.trim() && !day.contentCategory) {
        throw new AutomationValidationError(`Defina o tema ou a categoria do Carrossel Inteligente (${slotLabel(day)}) antes de ativar.`);
      }
      continue;
    }
    if (day.contentType === "CAROUSEL" && automation.imageMode !== "AUTO_TEMPLATE") {
      throw new AutomationValidationError(
        `${day.dayOfWeek.toLowerCase()} está configurado como Carrossel, mas isso só funciona com o modo de imagem "Gerar com IA sobre a imagem" (AUTO_TEMPLATE) — mude o modo de imagem da automação ou o tipo de conteúdo deste dia.`,
      );
    }
    const needsVisualText = automation.imageMode === "AUTO_TEMPLATE" && (day.contentType === "POST" || day.contentType === "CAROUSEL");
    if (day.contentMode === "MANUAL") {
      if (!day.manualCaption?.trim()) {
        throw new AutomationValidationError(`Escreva a legenda manual de ${day.dayOfWeek.toLowerCase()} antes de ativar.`);
      }
      if (needsVisualText && !day.visualText?.trim()) {
        throw new AutomationValidationError(`Escreva o texto que vai sobre a imagem de ${day.dayOfWeek.toLowerCase()} antes de ativar.`);
      }
    } else if (!day.prompt.trim()) {
      throw new AutomationValidationError(`Defina o que publicar em ${day.dayOfWeek.toLowerCase()} antes de ativar.`);
    }
    if (day.contentType === "POST" || day.contentType === "CAROUSEL") {
      if (!(day.imageMediaId ?? automation.fixedImageMediaId)) {
        throw new AutomationValidationError(`Defina uma imagem para o dia configurado como ${day.contentType === "POST" ? "Post" : "Carrossel"} (${day.dayOfWeek.toLowerCase()}).`);
      }
    } else {
      if (!(day.videoMediaId ?? automation.fixedVideoMediaId)) {
        throw new AutomationValidationError(`Defina um vídeo para o dia configurado como Reel (${day.dayOfWeek.toLowerCase()}).`);
      }
    }
  }
}

export async function activateAutomation(id: string, userId: string): Promise<void> {
  const loaded = await getAutomationDetails(id, userId);
  // No modo "Prompt único recorrente" o conteúdo mora na automação: valida
  // as linhas já com o conteúdo compartilhado aplicado (no modo CUSTOM,
  // effectiveDays devolve as linhas como estão).
  const automation: AutomationWithDays = { ...loaded, days: effectiveDays(loaded) };
  assertReadyToActivate(automation);
  if (automation.days.some((day) => day.enabled && day.contentMode === "AI" && day.contentType !== "SMART_CAROUSEL")) await assertPlanAllowsAi(userId);
  const updated = await setAutomationStatus(id, userId, "ACTIVE");
  if (!updated) throw new AutomationValidationError("Automação não encontrada.");
}

export interface PauseOptions {
  cancelScheduledRuns: boolean;
}

export async function pauseAutomation(id: string, userId: string, options: PauseOptions): Promise<void> {
  const automation = await getAutomationDetails(id, userId);
  const updated = await setAutomationStatus(id, userId, "PAUSED");
  if (!updated) throw new AutomationValidationError("Automação não encontrada.");
  if (options.cancelScheduledRuns) {
    await cancelPendingRunsForAutomation(automation.id);
  }
}

export async function archiveAutomation(id: string, userId: string): Promise<void> {
  const updated = await setAutomationStatus(id, userId, "ARCHIVED");
  if (!updated) throw new AutomationValidationError("Automação não encontrada.");
}

export async function deleteAutomation(id: string, userId: string): Promise<void> {
  const deleted = await deleteAutomationInDb(id, userId);
  if (!deleted) throw new AutomationValidationError("Automação não encontrada.");
}

export async function duplicateAutomation(id: string, userId: string): Promise<string> {
  const original = await getAutomationDetails(id, userId);
  const newId = await duplicateAutomationInDb(id, userId, `${original.name} (cópia)`.slice(0, MAX_NAME_LENGTH));
  if (!newId) throw new AutomationValidationError("Automação não encontrada.");
  return newId;
}

export async function listAutomationHistory(automationId: string, userId: string) {
  // Garante posse mesmo que a listagem também filtre por join.
  await getAutomationDetails(automationId, userId);
  return listRunsForAutomationOwnedByUser(automationId, userId);
}

/** Histórico com horário, tipo e o resultado da publicação (status na Meta, id da mídia, erro, prévia). */
export async function listAutomationHistoryDetailed(automationId: string, userId: string) {
  await getAutomationDetails(automationId, userId);
  return listRunHistoryForAutomationOwnedByUser(automationId, userId);
}

/**
 * Aprova uma execução em WAITING_APPROVAL: agenda a publicação já criada
 * (DRAFT) reaproveitando reschedulePost — o MESMO caminho que "Alterar
 * horário" usa no calendário editorial manual, nunca uma nova rota de
 * publicação. Se o horário original já passou (aprovação tardia), agenda
 * para dali a 2 minutos em vez de rejeitar por estar no passado.
 */
export async function approveAutomationRun(runId: string, userId: string): Promise<void> {
  const run = await getRunOwnedByUser(runId, userId);
  if (!run) throw new AutomationValidationError("Execução não encontrada.");
  if (run.status !== "WAITING_APPROVAL") {
    throw new AutomationValidationError("Esta execução não está aguardando aprovação.");
  }
  if (!run.publicationId) {
    throw new AutomationValidationError("Esta execução não tem uma publicação gerada.");
  }

  const automation = await getAutomationDetails(run.automationId, userId);
  const day = automation.days.find((candidate) => candidate.id === run.automationDayId);
  const originalInstant = day ? publishInstantUtc(run.runDate, day.publishTime, automation.timezone) : new Date();
  const target = originalInstant.getTime() > Date.now() + 30_000 ? originalInstant : new Date(Date.now() + 120_000);

  // Carrossel Inteligente: publica a versão ATUAL do projeto (inclui edições feitas no editor) e aponta a execução para o novo post.
  const carousel = await getProjectByAutomationRun(run.id);
  if (carousel) {
    try {
      const result = await publishCarousel(userId, carousel.id, {
        mode: "SCHEDULE",
        scheduledAt: target.toISOString(),
        timezone: automation.timezone,
        accountId: automation.instagramAccountId,
        source: "AUTOMATION",
      });
      await setRunPublication(run.id, result.postId);
    } catch (error) {
      if (error instanceof CarouselError) throw new AutomationValidationError(error.message);
      throw error;
    }
    await setRunStatus(run.id, "SCHEDULED");
    return;
  }

  try {
    await reschedulePost(run.publicationId, userId, target.toISOString(), automation.timezone);
  } catch (error) {
    if (error instanceof InstagramPostValidationError) throw new AutomationValidationError(error.message);
    throw error;
  }
  await setRunStatus(run.id, "SCHEDULED");
}

/** Rejeita uma execução em WAITING_APPROVAL: cancela a publicação gerada (o rascunho continua auditável no histórico). */
export async function rejectAutomationRun(runId: string, userId: string): Promise<void> {
  const run = await getRunOwnedByUser(runId, userId);
  if (!run) throw new AutomationValidationError("Execução não encontrada.");
  if (run.status !== "WAITING_APPROVAL") {
    throw new AutomationValidationError("Esta execução não está aguardando aprovação.");
  }
  if (run.publicationId) {
    try {
      await cancelPost(run.publicationId, userId);
    } catch (error) {
      if (!(error instanceof InstagramPostValidationError)) throw error;
      // Já pode estar cancelado/publicado por outro caminho — segue para marcar o run mesmo assim.
    }
  }
  await setRunStatus(run.id, "CANCELLED");
}

/**
 * "Regenerar" um Carrossel Inteligente que aguarda aprovação: cancela o rascunho, guarda o
 * projeto antigo como histórico (continua valendo na anti-repetição) e devolve a execução
 * para PENDING — o cron gera um conteúdo novo no próximo ciclo.
 */
export async function regenerateAutomationRun(runId: string, userId: string): Promise<void> {
  const run = await getRunOwnedByUser(runId, userId);
  if (!run) throw new AutomationValidationError("Execução não encontrada.");
  if (run.status !== "WAITING_APPROVAL") throw new AutomationValidationError("Esta execução não está aguardando aprovação.");
  const carousel = await getProjectByAutomationRun(run.id);
  if (!carousel) throw new AutomationValidationError("Só o Carrossel Inteligente pode ser regenerado.");
  if (run.publicationId) {
    try {
      await cancelPost(run.publicationId, userId);
    } catch (error) {
      if (!(error instanceof InstagramPostValidationError)) throw error;
    }
  }
  await detachProjectFromAutomationRun(carousel.id);
  await resetRunForRegeneration(run.id);
}

/** "Gerar exemplo" do Carrossel Inteligente: gera um carrossel completo para conferir — não publica, não agenda, não cobra a cota. */
export async function previewSmartCarousel(id: string, userId: string, deps: SmartCarouselRunDeps = {}): Promise<SmartCarouselPreviewResult> {
  const loaded = await getAutomationDetails(id, userId);
  const day = effectiveDays(loaded).find((candidate) => candidate.enabled && candidate.contentType === "SMART_CAROUSEL");
  if (!day) throw new AutomationValidationError("Nenhum dia está configurado como Carrossel Inteligente.");
  try {
    return await generateSmartCarouselPreview(loaded, day, deps);
  } catch (error) {
    if (error instanceof CarouselError) throw new AutomationValidationError(error.message);
    throw error;
  }
}

export { zonedToday };

export interface AutomationDashboardSummary {
  /** Próximo horário habilitado entre as automações ATIVAS. */
  next: {
    automationId: string;
    automationName: string;
    contentType: AutomationContentType;
    date: string;
    publishTime: string;
    atUtc: string;
    timezone: string;
    isToday: boolean;
  } | null;
  /** Contagem de "hoje" (no fuso de cada automação). */
  today: {
    published: number;
    storiesPublished: number;
    scheduled: number;
    waitingApproval: number;
    errors: number;
  };
}

/** Painel do Piloto Automático: próximo conteúdo + números do dia (Stories incluídos). */
export async function getAutomationDashboard(userId: string, now: Date = new Date()): Promise<AutomationDashboardSummary> {
  const items = await listAutomationsForUserInDb(userId);
  let next: AutomationDashboardSummary["next"] = null;
  for (const item of items.filter((candidate) => candidate.status === "ACTIVE")) {
    const automation = await getAutomationForUser(item.id, userId);
    if (!automation) continue;
    const found = findNextSlot(automation.days, now, automation.timezone);
    if (!found) continue;
    if (!next || found.atUtc.toISOString() < next.atUtc) {
      next = {
        automationId: automation.id,
        automationName: automation.name,
        contentType: found.slot.contentType,
        date: found.date,
        publishTime: found.slot.publishTime,
        atUtc: found.atUtc.toISOString(),
        timezone: automation.timezone,
        isToday: found.daysAhead === 0,
      };
    }
  }

  const since = new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
  const runs = await listRecentRunsForUser(userId, since);
  const today = { published: 0, storiesPublished: 0, scheduled: 0, waitingApproval: 0, errors: 0 };
  for (const run of runs) {
    if (run.runDate !== zonedToday(now, run.timezone).date) continue;
    if (run.publicationStatus === "PUBLISHED") {
      today.published += 1;
      if (run.contentType === "STORY") today.storiesPublished += 1;
    } else if (run.publicationStatus === "FAILED" || run.publicationStatus === "NEEDS_REVIEW" || run.runStatus === "FAILED") {
      today.errors += 1;
    } else if (run.runStatus === "WAITING_APPROVAL") {
      today.waitingApproval += 1;
    } else if (run.publicationStatus === "SCHEDULED" || run.publicationStatus === "PROCESSING" || run.runStatus === "SCHEDULED") {
      today.scheduled += 1;
    }
  }
  return { next, today };
}
