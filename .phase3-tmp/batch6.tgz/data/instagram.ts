/**
 * Catálogo da categoria "Instagram e Redes Sociais".
 *
 * Mantido deliberadamente separado de data/categories.ts e data/tools.ts
 * (catálogo de calculadoras, preso à URL /utilitarios/[categoria]/[ferramenta]
 * e coberto por testes de integridade próprios em __tests__/data/catalog.test.ts
 * e __tests__/seo/seo-rules.test.ts) porque esta categoria vive em uma URL
 * própria e mais curta (/instagram), a pedido explícito do prompt de
 * implementação. Continua seguindo o mesmo princípio do catálogo original:
 * nome, descrição e URLs ficam centralizados aqui — nenhum componente deve
 * duplicá-los.
 */

export const INSTAGRAM_CATEGORY = {
  id: "instagram",
  name: "Instagram e Redes Sociais",
  shortName: "Instagram",
  path: "/instagram",
  title: "Crie, agende e publique no Instagram",
  subtitle:
    "Crie posts, carrosséis e Reels de graça, sem login. Quando quiser, conecte seu Instagram e publique na hora ou deixe agendado.",
  description:
    "Crie posts, carrosséis e Reels grátis e, se quiser, publique ou agende direto no seu Instagram pelo Alilu.",
  metaTitle: "Criar, Agendar e Publicar Posts no Instagram Grátis | ALILU",
  metaDescription:
    "Crie posts, carrosséis e Reels para Instagram grátis e sem login. Quando quiser, conecte sua conta para publicar na hora ou agendar suas publicações.",
  icon: "instagram",
} as const;

export interface InstagramTool {
  id: string;
  name: string;
  shortName: string;
  path: string;
  description: string;
  pageDescription: string;
  metaTitle: string;
  metaDescription: string;
  keywords: string[];
  icon: string;
  status: "ativo" | "em-breve";
}

/**
 * Ferramentas já publicadas da categoria, cada uma com página própria e
 * componente real (nenhuma entrada aqui deve existir sem uma rota
 * funcional correspondente em app/instagram/*).
 */
export const instagramTools: InstagramTool[] = [
  {
    id: "criador-post-instagram",
    name: "Criador de Posts para Instagram Grátis",
    shortName: "Criador de Posts",
    path: "/instagram/criar-post",
    description:
      "Monte posts (e capas 9:16 para Stories e Reels) com templates, textos, cores e sua foto. Baixe em PNG/JPG ou publique e agende no Instagram.",
    pageDescription:
      "Escolha um template, personalize textos, cores e fotos, e baixe sua arte pronta — grátis e sem cadastro. Se quiser, publique ou agende direto no seu Instagram.",
    metaTitle: "Criar Post para Instagram Grátis Online | ALILU",
    metaDescription:
      "Crie posts para Instagram grátis: escolha modelos, personalize textos, cores e fotos e baixe em PNG ou JPG — ou publique e agende direto no Instagram.",
    keywords: [
      "criador de post para instagram",
      "criar post instagram grátis",
      "gerador de post instagram",
      "template instagram grátis",
      "editor de imagem para instagram",
    ],
    icon: "image",
    status: "ativo",
  },
  {
    id: "criador-carrossel-instagram",
    name: "Criador de Carrossel para Instagram Grátis",
    shortName: "Criador de Carrosséis",
    path: "/instagram/carrossel",
    description:
      "Monte carrosséis com vários slides, reordene e baixe tudo em ZIP — ou publique e agende o carrossel (2 a 10 imagens) no Instagram.",
    pageDescription:
      "Crie sequências de slides para carrossel, edite cada um separadamente, reordene por arraste e baixe todas as imagens em um único arquivo ZIP — grátis e sem cadastro. Se quiser, publique ou agende o carrossel no seu Instagram.",
    metaTitle: "Criar Carrossel para Instagram Grátis Online | ALILU",
    metaDescription:
      "Crie carrosséis para Instagram grátis: edite slides, organize a sequência e baixe em ZIP — ou conecte sua conta para publicar ou agendar.",
    keywords: [
      "criador de carrossel para instagram",
      "criar carrossel instagram grátis",
      "gerador de carrossel instagram",
      "template carrossel instagram",
      "carrossel instagram online",
    ],
    icon: "columns",
    status: "ativo",
  },
  {
    id: "criador-reels-instagram",
    name: "Criador de Reels para Instagram",
    shortName: "Criador de Reels",
    path: "/instagram/reels",
    description:
      "Envie um vídeo vertical, escreva a legenda, confira a prévia e prepare um Reel para publicar agora ou agendar.",
    pageDescription:
      "Crie Reels a partir de um vídeo seu, com legenda, hashtags, prévia e publicação pela conta Instagram conectada.",
    metaTitle: "Criar Reels para Instagram Online | ALILU",
    metaDescription:
      "Crie Reels para Instagram com upload de vídeo, legenda, hashtags, prévia e publicação ou agendamento pela conta conectada.",
    keywords: [
      "criar reels instagram",
      "publicar reels instagram",
      "agendar reels instagram",
      "editor de reels online",
    ],
    icon: "video",
    status: "ativo",
  },
  {
    id: "gerador-legendas-instagram",
    name: "Gerador de Legendas para Instagram Grátis",
    shortName: "Gerador de Legendas",
    path: "/instagram/legendas",
    description:
      "Monte legendas para Instagram a partir de modelos prontos: escolha o tipo de conteúdo, o estilo e o tamanho, e copie o texto pronto para editar.",
    pageDescription:
      "Escolha modelos, personalize o estilo e copie textos prontos para editar — grátis, sem cadastro e sem nenhuma promessa de geração por inteligência artificial.",
    metaTitle: "Gerador de Legendas para Instagram Grátis | ALILU",
    metaDescription:
      "Crie legendas para Instagram gratuitamente. Escolha modelos, personalize o estilo e copie textos prontos para editar.",
    keywords: [
      "gerador de legendas para instagram",
      "legenda para instagram grátis",
      "criar legenda instagram",
      "frases para instagram",
      "hashtags para instagram",
    ],
    icon: "type",
    status: "ativo",
  },
];

/**
 * Ferramentas planejadas para esta categoria, ainda sem implementação.
 * Exibidas apenas como texto informativo (roadmap), nunca como cards
 * clicáveis — evita links quebrados e evita anunciar como disponível algo
 * que ainda não existe.
 */
export interface PlannedInstagramTool {
  name: string;
  description: string;
  icon: string;
}

export const plannedInstagramTools: PlannedInstagramTool[] = [
  {
    name: "Redimensionador para Instagram",
    description:
      "Ajuste qualquer imagem para os formatos ideais de post, story e perfil.",
    icon: "scissors",
  },
];

/**
 * Publicação e agendamento no Instagram (Meta — Instagram API with
 * Instagram Login). Só lista o que está IMPLEMENTADO no código
 * (lib/instagram/backend/instagram-publish-service.ts); o que ainda não
 * existe fica em `notYetSupported` e nunca é anunciado como disponível.
 */
export const INSTAGRAM_PUBLISHING = {
  /** Minhas publicações / calendário (apresenta o recurso para quem não entrou). */
  schedulePath: "/instagram/painel/calendario",
  /** OAuth oficial da Meta; sem login no Alilu, leva antes para /entrar e volta. */
  connectPath: "/api/instagram/oauth/start?returnTo=%2Finstagram%2Fpainel%2Fcalendario",
  viralPostsPath: "/instagram/posts-virais",
  supported: [
    { label: "Post de imagem", detail: "Publica a arte criada no Alilu no feed." },
    { label: "Carrossel", detail: "De 2 a 10 imagens, na ordem que você escolher." },
    { label: "Reels", detail: "Vídeo MP4 ou MOV, de 3 segundos a 15 minutos." },
    { label: "Agendamento", detail: "Publicação automática no dia e horário escolhidos, mesmo com o Alilu fechado." },
  ],
  notYetSupported: ["Stories", "Carrossel com vídeo", "Capa personalizada do Reel na publicação"],
} as const;

/**
 * Piloto Automático de Conteúdo — automação semanal (gera, agenda e
 * publica sozinho pela conta Instagram conectada). Ver
 * docs/content-automation.md para a arquitetura completa.
 */
export const CONTENT_AUTOMATION = {
  /** Dashboard + "Minhas automações" (lista completa, com histórico por automação). */
  dashboardPath: "/instagram/piloto-automatico",
  newAutomationPath: "/instagram/piloto-automatico/nova",
} as const;

export interface InstagramMenuLink {
  href: string;
  label: string;
}

export interface InstagramMenuGroup {
  id: string;
  label: string;
  links: InstagramMenuLink[];
}

/**
 * Menu lateral da categoria Instagram (fechada por padrão; abre pelo "+"):
 * - Manual: o que o usuário cria e publica ele mesmo.
 * - Automatizado: o que agenda/gera sozinho (Carrossel Inteligente e Piloto Automático).
 * "Posts Virais" saiu do menu (é o mesmo que "Criar post"); a rota continua existindo.
 */
export const instagramMenuGroups: InstagramMenuGroup[] = [
  {
    id: "manual",
    label: "Manual",
    links: [
      { href: "/instagram/criar-post", label: "Criar post" },
      { href: "/instagram/carrossel", label: "Carrossel" },
      { href: "/instagram/reels", label: "Reels" },
      { href: "/instagram/legendas", label: "Legendas" },
    ],
  },
  {
    id: "automatizado",
    label: "Automatizado",
    links: [
      { href: "/instagram/painel/calendario", label: "Agendar e publicar" },
      { href: "/instagram/carrossel-inteligente", label: "Carrossel Inteligente" },
      { href: "/instagram/piloto-automatico", label: "Piloto Automático" },
    ],
  },
];

/** Links soltos dentro da categoria Instagram (o importador também continua em Vídeos). */
export const instagramMenuExtraLinks: InstagramMenuLink[] = [{ href: "/videos/importar-instagram", label: "Importar do Instagram" }];

/** Lista plana (compatibilidade). */
export const instagramMenuLinks: InstagramMenuLink[] = [...instagramMenuGroups.flatMap((group) => group.links), ...instagramMenuExtraLinks];

export function getInstagramToolByPath(path: string): InstagramTool | undefined {
  return instagramTools.find((tool) => tool.path === path);
}
