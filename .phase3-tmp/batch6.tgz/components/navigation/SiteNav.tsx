"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import { Icon } from "@/components/ui/Icon";
import { categories } from "@/data/categories";
import { INSTAGRAM_CATEGORY, instagramMenuExtraLinks, instagramMenuGroups } from "@/data/instagram";
import { LOTTERIES_CATEGORY } from "@/data/lotteries";
import { VIDEOS_CATEGORY } from "@/data/videos";
import type { HeaderAuthState } from "@/components/layout/auth-state";

type NavigationLink = {
  href: string;
  label: string;
  icon: string;
};

const catalogLinks: NavigationLink[] = [
  { href: "/", label: "Início", icon: "home" },
  { href: "/utilitarios", label: "Todas as ferramentas", icon: "wrench" },
];

const categoryLinks: NavigationLink[] = categories.map((category) => ({
  href: `/utilitarios/${category.id}`,
  label: category.name,
  icon: category.icon,
}));

// Categoria "Instagram e Redes Sociais": vive em /instagram (fora de
// /utilitarios/[categoria], ver data/instagram.ts) mas aparece no menu
// exatamente como as demais categorias.
const instagramCategoryLink: NavigationLink = {
  href: INSTAGRAM_CATEGORY.path,
  label: INSTAGRAM_CATEGORY.shortName,
  icon: INSTAGRAM_CATEGORY.icon,
};

// Categoria "Loterias": mesmo padrão de "Instagram e Redes Sociais" acima —
// vive em /loterias (fora de /utilitarios/[categoria], ver
// data/lotteries.ts) mas aparece no menu como as demais categorias.
const lotteriesCategoryLink: NavigationLink = {
  href: LOTTERIES_CATEGORY.path,
  label: LOTTERIES_CATEGORY.shortName,
  icon: LOTTERIES_CATEGORY.icon,
};

// Categoria "Vídeos": mesmo padrão de "Loterias" e "Instagram e Redes
// Sociais" acima — vive em /videos (fora de /utilitarios/[categoria], ver
// data/videos.ts) mas aparece no menu como as demais categorias.
const videosCategoryLink: NavigationLink = {
  href: VIDEOS_CATEGORY.path,
  label: VIDEOS_CATEGORY.shortName,
  icon: VIDEOS_CATEGORY.icon,
};

// Agenda pessoal (/agenda) — compromissos com lembrete por e-mail.
const agendaLink: NavigationLink = { href: "/agenda", label: "Agenda", icon: "calendar" };

function isActiveLink(pathname: string, href: string) {
  if (href === "/" || href === "/utilitarios") {
    return pathname === href;
  }

  return pathname === href || pathname.startsWith(`${href}/`);
}

function NavigationItem({
  link,
  pathname,
  onNavigate,
}: {
  link: NavigationLink;
  pathname: string;
  onNavigate?: () => void;
}) {
  const isActive = isActiveLink(pathname, link.href);

  return (
    <li>
      <Link
        href={link.href}
        aria-current={isActive ? "page" : undefined}
        onClick={onNavigate}
        className={`group flex min-h-11 items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent ${
          isActive
            ? "bg-brand-primary-soft text-brand-primary"
            : "text-zinc-600 hover:bg-white hover:text-zinc-950"
        }`}
      >
        <span
          className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-md transition-colors ${
            isActive
              ? "bg-white text-brand-primary shadow-sm ring-1 ring-brand-primary/15"
              : "bg-zinc-100 text-zinc-500 group-hover:bg-zinc-200 group-hover:text-zinc-800"
          }`}
        >
          <Icon name={link.icon} className="h-4 w-4" />
        </span>
        <span className="min-w-0 truncate">{link.label}</span>
      </Link>
    </li>
  );
}

function isActivePath(pathname: string, href: string) {
  return pathname === href || pathname.startsWith(`${href}/`);
}

function SubLink({ href, label, pathname, onNavigate }: { href: string; label: string; pathname: string; onNavigate?: () => void }) {
  const active = isActivePath(pathname, href);
  return (
    <Link
      href={href}
      onClick={onNavigate}
      aria-current={active ? "page" : undefined}
      className={`flex min-h-9 items-center rounded-md px-2 text-sm transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-accent ${
        active ? "bg-brand-primary-soft font-medium text-brand-primary" : "text-zinc-600 hover:bg-white hover:text-zinc-950"
      }`}
    >
      {label}
    </Link>
  );
}

function ToggleButton({ open, label, onClick }: { open: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-expanded={open}
      aria-label={`${open ? "Fechar" : "Abrir"} ${label}`}
      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md text-zinc-500 hover:bg-white hover:text-zinc-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-accent"
    >
      <Icon name={open ? "chevron-down" : "chevron-right"} className="h-4 w-4" />
    </button>
  );
}

/** Subgrupo (Manual / Automatizado): fechado até clicar, a menos que a página atual esteja dentro dele. */
function InstagramSubGroup({ group, pathname, onNavigate }: { group: (typeof instagramMenuGroups)[number]; pathname: string; onNavigate?: () => void }) {
  const containsActive = group.links.some((link) => isActivePath(pathname, link.href));
  const [open, setOpen] = useState(containsActive);
  return (
    <div>
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        className="flex min-h-9 w-full items-center justify-between rounded-md px-2 text-left text-sm font-medium text-zinc-700 hover:bg-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-accent"
      >
        {group.label}
        <Icon name={open ? "chevron-down" : "chevron-right"} className="h-4 w-4 text-zinc-500" />
      </button>
      {open ? (
        <div role="group" aria-label={group.label} className="ml-3 flex flex-col border-l border-zinc-200 pl-2">
          {group.links.map((link) => (
            <SubLink key={link.href} href={link.href} label={link.label} pathname={pathname} onNavigate={onNavigate} />
          ))}
        </div>
      ) : null}
    </div>
  );
}

/**
 * Categoria Instagram: o link leva à página da categoria e o botão ao lado
 * abre/fecha as opções (Manual, Automatizado e o importador). Fechada por
 * padrão; só abre sozinha quando a página atual está dentro do Instagram.
 */
function InstagramMenu({ pathname, onNavigate }: { pathname: string; onNavigate?: () => void }) {
  const inside = pathname === "/instagram" || pathname.startsWith("/instagram/") || instagramMenuExtraLinks.some((link) => isActivePath(pathname, link.href));
  const [open, setOpen] = useState(inside);
  const isActive = isActiveLink(pathname, instagramCategoryLink.href);
  return (
    <li>
      <div className="flex items-center gap-1">
        <Link
          href={instagramCategoryLink.href}
          aria-current={isActive ? "page" : undefined}
          onClick={onNavigate}
          className={`group flex min-h-11 min-w-0 flex-1 items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent ${
            isActive ? "bg-brand-primary-soft text-brand-primary" : "text-zinc-600 hover:bg-white hover:text-zinc-950"
          }`}
        >
          <span
            className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-md transition-colors ${
              isActive ? "bg-white text-brand-primary shadow-sm ring-1 ring-brand-primary/15" : "bg-zinc-100 text-zinc-500 group-hover:bg-zinc-200 group-hover:text-zinc-800"
            }`}
          >
            <Icon name={instagramCategoryLink.icon} className="h-4 w-4" />
          </span>
          <span className="min-w-0 truncate">{instagramCategoryLink.label}</span>
        </Link>
        <ToggleButton open={open} label="opções do Instagram" onClick={() => setOpen((value) => !value)} />
      </div>
      {open ? (
        <div role="group" aria-label="Opções do Instagram" className="ml-6 flex flex-col gap-0.5 border-l border-zinc-200 pl-3">
          {instagramMenuGroups.map((group) => (
            <InstagramSubGroup key={group.id} group={group} pathname={pathname} onNavigate={onNavigate} />
          ))}
          {instagramMenuExtraLinks.map((link) => (
            <SubLink key={link.href} href={link.href} label={link.label} pathname={pathname} onNavigate={onNavigate} />
          ))}
        </div>
      ) : null}
    </li>
  );
}

/**
 * Seção de conta no topo do menu mobile — mesmo estado (auth) do menu de
 * desktop (components/layout/UserMenu.tsx), só que sempre expandida (sem
 * popover) porque já está dentro do painel deslizante.
 */
function MobileAccountSection({ auth, onNavigate }: { auth: HeaderAuthState; onNavigate?: () => void }) {
  if (auth.status === "loading") {
    return <div aria-hidden className="h-16 animate-pulse rounded-md bg-zinc-100" />;
  }

  if (auth.status === "signed-out") {
    return (
      <Link
        href="/entrar"
        onClick={onNavigate}
        className="flex min-h-11 items-center gap-3 rounded-md bg-zinc-100 px-3 py-2 text-sm font-medium text-zinc-900 hover:bg-zinc-200"
      >
        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white text-zinc-500">
          <Icon name="user" className="h-4 w-4" />
        </span>
        Entrar
      </Link>
    );
  }

  const { user } = auth;
  const displayName = user.name?.trim() || user.email;

  return (
    <div className="rounded-md bg-zinc-100 p-3">
      <div className="flex items-center gap-3">
        {user.image ? (
          // eslint-disable-next-line @next/next/no-img-element -- avatar externo (Google), mesmo padrão do UserMenu.
          <img src={user.image} alt="" width={32} height={32} className="h-8 w-8 shrink-0 rounded-full" referrerPolicy="no-referrer" />
        ) : (
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white text-zinc-500">
            <Icon name="user" className="h-4 w-4" />
          </span>
        )}
        <div className="min-w-0">
          <p className="truncate text-sm font-medium text-zinc-900">{displayName}</p>
          <p className="truncate text-xs text-zinc-500">{user.email}</p>
        </div>
      </div>
      <div className="mt-2 flex flex-col">
        <Link href="/minha-conta" onClick={onNavigate} className="flex min-h-9 items-center rounded px-2 text-sm text-zinc-700 hover:bg-white">
          Minha conta
        </Link>
        {user.isAdmin ? (
          <Link href="/admin" onClick={onNavigate} className="flex min-h-9 items-center rounded px-2 text-sm font-medium text-teal-800 hover:bg-white">
            Admin
          </Link>
        ) : null}
        <button
          type="button"
          onClick={() => {
            onNavigate?.();
            void signOut({ callbackUrl: "/?saiu=1" });
          }}
          className="flex min-h-9 items-center gap-2 rounded px-2 text-left text-sm text-zinc-700 hover:bg-white"
        >
          <Icon name="log-out" className="h-4 w-4" />
          Sair
        </button>
      </div>
    </div>
  );
}

function NavigationList({
  pathname,
  onNavigate,
  auth,
}: {
  pathname: string;
  onNavigate?: () => void;
  auth?: HeaderAuthState;
}) {
  return (
    <>
      {auth ? (
        <>
          <MobileAccountSection auth={auth} onNavigate={onNavigate} />
          <div className="my-5 border-t border-zinc-200" />
        </>
      ) : null}
      <ul className="space-y-1">
        {catalogLinks.map((link) => (
          <NavigationItem
            key={link.href}
            link={link}
            pathname={pathname}
            onNavigate={onNavigate}
          />
        ))}
      </ul>
      <div className="my-5 border-t border-zinc-200" />
      <p className="px-3 text-xs font-semibold uppercase tracking-wider text-zinc-500">
        Categorias
      </p>
      <ul className="mt-2 space-y-1">
        <InstagramMenu pathname={pathname} onNavigate={onNavigate} />
        <NavigationItem link={lotteriesCategoryLink} pathname={pathname} onNavigate={onNavigate} />
        <NavigationItem link={videosCategoryLink} pathname={pathname} onNavigate={onNavigate} />
        <NavigationItem link={agendaLink} pathname={pathname} onNavigate={onNavigate} />
        {categoryLinks.map((link) => (
          <NavigationItem
            key={link.href}
            link={link}
            pathname={pathname}
            onNavigate={onNavigate}
          />
        ))}
      </ul>
    </>
  );
}

export function SiteSidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden w-64 shrink-0 border-r border-brand-primary/10 bg-[#f7fbfb] xl:block print:hidden">
      <nav
        aria-label="Navegação principal"
        className="sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto px-3 py-5"
      >
        <p className="px-3 text-xs font-semibold uppercase tracking-wider text-zinc-500">
          Navegação
        </p>
        <div className="mt-3">
          <NavigationList pathname={pathname} />
        </div>
      </nav>
    </aside>
  );
}

export function MobileNavigation({ auth }: { auth: HeaderAuthState }) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) {
      return;
    }

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeButtonRef.current?.focus();

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        triggerRef.current?.focus();
        return;
      }

      if (event.key !== "Tab" || !panelRef.current) {
        return;
      }

      const focusableElements = Array.from(
        panelRef.current.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      );
      const firstElement = focusableElements[0];
      const lastElement = focusableElements.at(-1);

      if (!firstElement || !lastElement) {
        return;
      }

      if (event.shiftKey && document.activeElement === firstElement) {
        event.preventDefault();
        lastElement.focus();
      } else if (!event.shiftKey && document.activeElement === lastElement) {
        event.preventDefault();
        firstElement.focus();
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [open]);

  const closeNavigation = () => setOpen(false);

  return (
    <div className="xl:hidden">
      <button
        ref={triggerRef}
        type="button"
        onClick={() => setOpen(true)}
        aria-expanded={open}
        aria-controls="menu-mobile"
        aria-label="Abrir menu de navegação"
        className="flex h-11 w-11 items-center justify-center rounded-md text-brand-primary transition-colors hover:bg-brand-primary-soft focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent"
      >
        <Icon name="menu" className="h-5 w-5" />
      </button>

      {open
        ? createPortal(
            <div className="fixed inset-0 z-50 flex">
              <button
                type="button"
                aria-label="Fechar menu de navegação"
                className="absolute inset-0 bg-zinc-950/35"
                onClick={closeNavigation}
              />
              <nav
                ref={panelRef}
                id="menu-mobile"
                aria-label="Navegação principal"
                aria-modal="true"
                role="dialog"
                tabIndex={-1}
                className="relative flex h-full w-[min(20rem,calc(100vw-2rem))] flex-col overflow-y-auto bg-white px-4 py-5 shadow-2xl outline-none"
              >
                <div className="flex items-center justify-between px-2">
                  <p className="text-sm font-semibold text-zinc-950">Menu</p>
                  <button
                    ref={closeButtonRef}
                    type="button"
                    onClick={closeNavigation}
                    aria-label="Fechar menu de navegação"
                    className="flex h-11 w-11 items-center justify-center rounded-md text-brand-primary transition-colors hover:bg-brand-primary-soft focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent"
                  >
                    <Icon name="close" className="h-5 w-5" />
                  </button>
                </div>
                <div className="mt-5">
                  <NavigationList pathname={pathname} onNavigate={closeNavigation} auth={auth} />
                </div>
              </nav>
            </div>,
            document.body,
          )
        : null}
    </div>
  );
}
