// Piloto Automático de Conteúdo ponta a ponta contra um Postgres REAL em
// memória (PGlite, mesmas migrações de produção). Só o provedor de IA é
// simulado — o SQL de claim/lock/idempotência é o de verdade, mesma técnica
// já provada em instagram-scheduler.test.ts para o agendador de publicação.
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createTestDb, seedUserWithAccount, type TestDb } from "../helpers/pglite-db";

let db: TestDb;
vi.mock("@/lib/db/client", () => ({
  getDb: () => db.sql,
  assertDatabaseConfigured: () => undefined,
}));

const fakeProvider = {
  generatePost: vi.fn(),
  generateReel: vi.fn(),
};
vi.mock("@/lib/content-automation/backend/provider-factory", () => ({
  getContentAIProvider: () => fakeProvider,
}));

const fakeRenderAndStoreAutomationArt = vi.fn();
const fakeRenderAndStoreAutomationCarousel = vi.fn();
vi.mock("@/lib/instagram/backend/template-render-service", () => ({
  renderAndStoreAutomationArt: (...args: unknown[]) => fakeRenderAndStoreAutomationArt(...args),
  renderAndStoreAutomationCarousel: (...args: unknown[]) => fakeRenderAndStoreAutomationCarousel(...args),
}));

const repo = await import("@/lib/content-automation/backend/automation-repository");
const runRepo = await import("@/lib/content-automation/backend/automation-run-repository");
const cron = await import("@/lib/content-automation/backend/content-automation-cron");
const service = await import("@/lib/content-automation/backend/automation-service");
const postRepo = await import("@/lib/instagram/backend/instagram-post-repository");

function happyPost(overrides: Partial<Awaited<ReturnType<typeof fakeProvider.generatePost>>["content"]> = {}) {
  fakeProvider.generatePost.mockResolvedValue({
    content: {
      title: "Título gerado",
      caption: "Legenda gerada pela IA",
      hashtags: ["#alilu", "#promo"],
      cta: "Chama no direct!",
      visualDescription: "Foto do produto em fundo claro",
      ...overrides,
    },
    usage: { provider: "anthropic", model: "claude-test", tokensInput: 100, tokensOutput: 50 },
  });
}

function happyReel(overrides: Partial<Awaited<ReturnType<typeof fakeProvider.generateReel>>["content"]> = {}) {
  fakeProvider.generateReel.mockResolvedValue({
    content: {
      title: "Reel gerado",
      hook: "Você sabia?",
      script: "Roteiro do reel",
      caption: "Legenda do reel",
      hashtags: ["#reels"],
      coverText: "Capa",
      ...overrides,
    },
    usage: { provider: "anthropic", model: "claude-test", tokensInput: 80, tokensOutput: 40 },
  });
}

async function activePostAutomation(
  seed: Awaited<ReturnType<typeof seedUserWithAccount>>,
  overrides: {
    dayOfWeek?: string;
    publishTime?: string;
    generationLeadMinutes?: number;
    autoPublish?: boolean;
    requireApproval?: boolean;
    contentType?: "POST" | "REEL";
    imageMediaId?: string | null;
    videoMediaId?: string | null;
  } = {},
) {
  const dayOfWeek = overrides.dayOfWeek ?? "WEDNESDAY";
  const contentType = overrides.contentType ?? "POST";
  const automationId = await repo.createAutomation({
    userId: seed.userId,
    instagramAccountId: seed.accountId,
    name: "Automação de teste",
    description: "",
    timezone: "America/Sao_Paulo",
    brandContext: "Marca de utilitários domésticos",
    autoPublish: overrides.autoPublish ?? false,
    requireApproval: overrides.requireApproval ?? true,
    generationLeadMinutes: overrides.generationLeadMinutes ?? 120,
    imageMode: "FIXED_IMAGE",
    fixedImageMediaId: seed.mediaId,
    videoSelection: "FIXED",
    fixedVideoMediaId: seed.videoId,
  });

  await repo.updateAutomationDay(automationId, seed.userId, dayOfWeek as never, {
    enabled: true,
    contentType,
    prompt: "Fale sobre a promoção de hoje",
    publishTime: overrides.publishTime ?? "19:00",
    imageMediaId: overrides.imageMediaId,
    videoMediaId: overrides.videoMediaId,
  });

  await repo.setAutomationStatus(automationId, seed.userId, "ACTIVE");
  return automationId;
}

beforeEach(async () => {
  db = await createTestDb();
  happyPost();
  happyReel();
  vi.spyOn(console, "info").mockImplementation(() => undefined);
  vi.spyOn(console, "error").mockImplementation(() => undefined);
});

afterEach(async () => {
  await db.close();
  fakeProvider.generatePost.mockReset();
  fakeProvider.generateReel.mockReset();
  fakeRenderAndStoreAutomationArt.mockReset();
  vi.restoreAllMocks();
});

describe("cenário crítico: cron rodando duas vezes ao mesmo tempo", () => {
  it("gera conteúdo e cria a publicação UMA única vez para o mesmo automation_id + dia", async () => {
    const seed = await seedUserWithAccount(db);
    await activePostAutomation(seed, { dayOfWeek: "WEDNESDAY", publishTime: "19:00", generationLeadMinutes: 120 });

    // "Agora" = quarta 17h em São Paulo (20h UTC) = exatamente a janela de pré-geração.
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [first, second] = await Promise.all([
      cron.runContentAutomationCron({ now }),
      cron.runContentAutomationCron({ now }),
    ]);

    expect(fakeProvider.generatePost).toHaveBeenCalledTimes(1);
    const allResults = [...first, ...second];
    expect(allResults).toHaveLength(1);
    expect(allResults[0].status).toBe("WAITING_APPROVAL");

    const [runRow] = await db.sql`select * from automation_runs`;
    expect(runRow.status).toBe("WAITING_APPROVAL");
    expect(runRow.publication_id).not.toBeNull();

    // Rodar de novo (terceira vez) não gera de novo: já existe run para o dia.
    await cron.runContentAutomationCron({ now });
    expect(fakeProvider.generatePost).toHaveBeenCalledTimes(1);
    const runsAfter = await db.sql`select id from automation_runs`;
    expect(runsAfter).toHaveLength(1);
  });
});

describe("modo aprovação vs. modo automático", () => {
  it("modo aprovação (padrão): cria DRAFT em WAITING_APPROVAL, nunca agenda sozinho", async () => {
    const seed = await seedUserWithAccount(db);
    await activePostAutomation(seed, { requireApproval: true, autoPublish: false });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("WAITING_APPROVAL");

    const [post] = await db.sql`select * from instagram_posts where id = ${(await db.sql`select publication_id from automation_runs`)[0].publication_id}`;
    expect(post.status).toBe("DRAFT");
    expect(post.scheduled_at_utc).toBeNull();
    expect(post.source).toBe("AUTOMATION");
  });

  it("modo automático (sem aprovação): já cria SCHEDULED no horário certo, pronto para o agendador existente publicar", async () => {
    const seed = await seedUserWithAccount(db);
    await activePostAutomation(seed, { requireApproval: false, autoPublish: true, publishTime: "19:00" });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("SCHEDULED");

    const runRow = (await db.sql`select * from automation_runs`)[0];
    const [post] = await db.sql`select * from instagram_posts where id = ${runRow.publication_id}`;
    expect(post.status).toBe("SCHEDULED");
    expect(new Date(post.scheduled_at_utc as string).toISOString()).toBe("2026-09-23T22:00:00.000Z");
  });

  it("aprovar uma execução WAITING_APPROVAL agenda a publicação já gerada (reaproveita reschedulePost)", async () => {
    const seed = await seedUserWithAccount(db);
    await activePostAutomation(seed, { requireApproval: true, publishTime: "19:00" });
    const now = () => new Date("2026-09-23T20:00:00.000Z");
    await cron.runContentAutomationCron({ now });

    const runRow = (await db.sql`select * from automation_runs`)[0];
    await service.approveAutomationRun(runRow.id as string, seed.userId);

    const [post] = await db.sql`select * from instagram_posts where id = ${runRow.publication_id}`;
    expect(post.status).toBe("SCHEDULED");
    const [runAfter] = await db.sql`select status from automation_runs where id = ${runRow.id}`;
    expect(runAfter.status).toBe("SCHEDULED");
  });

  it("rejeitar uma execução WAITING_APPROVAL cancela a publicação gerada", async () => {
    const seed = await seedUserWithAccount(db);
    await activePostAutomation(seed, { requireApproval: true });
    const now = () => new Date("2026-09-23T20:00:00.000Z");
    await cron.runContentAutomationCron({ now });

    const runRow = (await db.sql`select * from automation_runs`)[0];
    await service.rejectAutomationRun(runRow.id as string, seed.userId);

    const [post] = await db.sql`select * from instagram_posts where id = ${runRow.publication_id}`;
    expect(post.status).toBe("CANCELLED");
    const [runAfter] = await db.sql`select status from automation_runs where id = ${runRow.id}`;
    expect(runAfter.status).toBe("CANCELLED");
  });
});

describe("modo manual (sem IA) por dia", () => {
  async function activeManualAutomation(
    seed: Awaited<ReturnType<typeof seedUserWithAccount>>,
    overrides: { contentType?: "POST" | "REEL"; manualCaption?: string } = {},
  ) {
    const contentType = overrides.contentType ?? "POST";
    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Automação manual de teste",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "FIXED_IMAGE",
      fixedImageMediaId: seed.mediaId,
      videoSelection: "FIXED",
      fixedVideoMediaId: seed.videoId,
    });

    // Propositalmente SEM prompt — modo manual nunca deveria exigir um.
    await repo.updateAutomationDay(automationId, seed.userId, "WEDNESDAY" as never, {
      enabled: true,
      contentType,
      contentMode: "MANUAL",
      prompt: "",
      manualCaption: overrides.manualCaption ?? "Legenda escrita à mão, publicada exatamente assim.",
      publishTime: "19:00",
    });

    await repo.setAutomationStatus(automationId, seed.userId, "ACTIVE");
    return automationId;
  }

  it("publica a legenda manual tal como escrita, sem chamar o provedor de IA", async () => {
    const seed = await seedUserWithAccount(db);
    await activeManualAutomation(seed, { manualCaption: "Promoção desta semana: 20% off em tudo!" });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("WAITING_APPROVAL");
    expect(fakeProvider.generatePost).not.toHaveBeenCalled();
    expect(fakeProvider.generateReel).not.toHaveBeenCalled();

    const runRow = (await db.sql`select * from automation_runs`)[0];
    const [post] = await db.sql`select * from instagram_posts where id = ${runRow.publication_id}`;
    expect(post.caption).toBe("Promoção desta semana: 20% off em tudo!");
  });

  it("funciona também para REEL em modo manual, sem chamar o provedor de IA", async () => {
    const seed = await seedUserWithAccount(db);
    await activeManualAutomation(seed, { contentType: "REEL", manualCaption: "Legenda manual do reel." });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("WAITING_APPROVAL");
    expect(fakeProvider.generateReel).not.toHaveBeenCalled();
    expect(fakeProvider.generatePost).not.toHaveBeenCalled();

    const runRow = (await db.sql`select * from automation_runs`)[0];
    const [post] = await db.sql`select * from instagram_posts where id = ${runRow.publication_id}`;
    expect(post.post_type).toBe("reels");
    expect(post.caption).toBe("Legenda manual do reel.");
  });

  it("não deixa ativar um dia manual sem legenda escrita (prompt vazio não conta)", async () => {
    const seed = await seedUserWithAccount(db);
    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Automação manual incompleta",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "FIXED_IMAGE",
      fixedImageMediaId: seed.mediaId,
      videoSelection: "FIXED",
      fixedVideoMediaId: seed.videoId,
    });
    await repo.updateAutomationDay(automationId, seed.userId, "WEDNESDAY" as never, {
      enabled: true,
      contentType: "POST",
      contentMode: "MANUAL",
      manualCaption: "",
    });

    await expect(service.activateAutomation(automationId, seed.userId)).rejects.toThrow(/legenda manual/i);
  });
});

describe("modo AUTO_TEMPLATE (IA/manual desenha o texto sobre a imagem)", () => {
  async function activeAutoTemplateAutomation(
    seed: Awaited<ReturnType<typeof seedUserWithAccount>>,
    overrides: { contentMode?: "AI" | "MANUAL"; visualText?: string; manualCaption?: string; templateId?: string | null } = {},
  ) {
    const contentMode = overrides.contentMode ?? "AI";
    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Automação AUTO_TEMPLATE de teste",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "Marca de utilitários domésticos",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "AUTO_TEMPLATE",
      fixedImageMediaId: seed.mediaId,
      videoSelection: "FIXED",
      fixedVideoMediaId: seed.videoId,
    });

    await repo.updateAutomationDay(automationId, seed.userId, "WEDNESDAY" as never, {
      enabled: true,
      contentType: "POST",
      contentMode,
      prompt: contentMode === "AI" ? "Fale sobre a promoção de hoje" : "",
      manualCaption: contentMode === "MANUAL" ? (overrides.manualCaption ?? "Legenda manual completa, com CTA.") : undefined,
      visualText: contentMode === "MANUAL" ? (overrides.visualText ?? "20% OFF hoje") : undefined,
      templateId: overrides.templateId,
      publishTime: "19:00",
    });

    await repo.setAutomationStatus(automationId, seed.userId, "ACTIVE");
    return automationId;
  }

  it("modo IA: pede legenda + texto visual numa única chamada e usa a mídia renderizada pelo template", async () => {
    const seed = await seedUserWithAccount(db);
    // A mídia gerada é uma linha real de instagram_media (é o que
    // renderAndStoreAutomationArt faz de verdade, via insertInstagramMedia) —
    // instagram_post_items.media_id tem FK para instagram_media, então o
    // mock precisa devolver um id existente, não uma string qualquer.
    const [renderedMedia] = await db.sql`
      insert into instagram_media (user_id, storage_url, media_type)
      values (${seed.userId}, 'https://blob.example.com/generated-ai.jpg', 'image') returning id
    `;
    fakeRenderAndStoreAutomationArt.mockResolvedValue(renderedMedia.id);
    happyPost({ caption: "Legenda gerada pela IA", cta: "", hashtags: [], visualText: "Frase curta pra imagem" });
    await activeAutoTemplateAutomation(seed, { contentMode: "AI", templateId: "promocao" });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("WAITING_APPROVAL");

    // Uma única chamada à IA — não duas (legenda e texto visual vêm juntos).
    expect(fakeProvider.generatePost).toHaveBeenCalledTimes(1);
    const [[callArgs]] = fakeProvider.generatePost.mock.calls;
    expect(callArgs.includeVisualText).toBe(true);
    // Correção do bug "a IA fala segunda-feira numa automação de quarta":
    // o dia REALMENTE configurado (o dia do teste é sempre WEDNESDAY) tem
    // que chegar explicitamente no prompt, nunca um valor fixo/ausente.
    expect(callArgs.dayOfWeekLabel).toBe("Quarta-feira");

    expect(fakeRenderAndStoreAutomationArt).toHaveBeenCalledTimes(1);
    const [renderArgs] = fakeRenderAndStoreAutomationArt.mock.calls[0];
    expect(renderArgs).toMatchObject({
      userId: seed.userId,
      templateId: "promocao",
      sourceImageUrl: "https://blob.example.com/1.jpg",
      sourceMediaId: seed.mediaId,
      visualText: "Frase curta pra imagem",
      overlayOpacity: null, // dia não configurou véu explícito — template-render-service aplica o padrão (20%).
    });
    expect(renderArgs.automationRunId).toEqual(expect.any(String));

    const runRow = (await db.sql`select * from automation_runs`)[0];
    const [post] = await db.sql`select * from instagram_posts where id = ${runRow.publication_id}`;
    expect(post.caption).toBe("Legenda gerada pela IA");
    const [item] = await db.sql`select media_id from instagram_post_items where post_id = ${runRow.publication_id}`;
    expect(item.media_id).toBe(renderedMedia.id);
  });

  it("modo manual: usa a legenda e o texto visual escritos à mão, sem chamar a IA, mas ainda renderiza a arte", async () => {
    const seed = await seedUserWithAccount(db);
    const [renderedMedia] = await db.sql`
      insert into instagram_media (user_id, storage_url, media_type)
      values (${seed.userId}, 'https://blob.example.com/generated-manual.jpg', 'image') returning id
    `;
    fakeRenderAndStoreAutomationArt.mockResolvedValue(renderedMedia.id);
    await activeAutoTemplateAutomation(seed, {
      contentMode: "MANUAL",
      manualCaption: "Promoção de quarta-feira, corre lá!",
      visualText: "Só hoje: 20% OFF",
      templateId: "frase-motivacional",
    });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("WAITING_APPROVAL");
    expect(fakeProvider.generatePost).not.toHaveBeenCalled();

    expect(fakeRenderAndStoreAutomationArt).toHaveBeenCalledTimes(1);
    const [renderArgs] = fakeRenderAndStoreAutomationArt.mock.calls[0];
    expect(renderArgs).toMatchObject({
      templateId: "frase-motivacional",
      sourceImageUrl: "https://blob.example.com/1.jpg",
      visualText: "Só hoje: 20% OFF",
    });

    const runRow = (await db.sql`select * from automation_runs`)[0];
    const [post] = await db.sql`select * from instagram_posts where id = ${runRow.publication_id}`;
    expect(post.caption).toBe("Promoção de quarta-feira, corre lá!");
    const [item] = await db.sql`select media_id from instagram_post_items where post_id = ${runRow.publication_id}`;
    expect(item.media_id).toBe(renderedMedia.id);
  });

  it("não deixa ativar um dia manual em AUTO_TEMPLATE sem o texto visual, mesmo com legenda preenchida", async () => {
    const seed = await seedUserWithAccount(db);
    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Automação AUTO_TEMPLATE incompleta",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "AUTO_TEMPLATE",
      fixedImageMediaId: seed.mediaId,
      videoSelection: "FIXED",
      fixedVideoMediaId: seed.videoId,
    });
    await repo.updateAutomationDay(automationId, seed.userId, "WEDNESDAY" as never, {
      enabled: true,
      contentType: "POST",
      contentMode: "MANUAL",
      manualCaption: "Legenda preenchida normalmente.",
      visualText: "",
    });

    await expect(service.activateAutomation(automationId, seed.userId)).rejects.toThrow(/texto.*imagem/i);
  });

  it("usa o dia da semana configurado (quinta-feira) no prompt, mesmo quando o cron roda em outro dia real do calendário", async () => {
    const seed = await seedUserWithAccount(db);
    const [renderedMedia] = await db.sql`
      insert into instagram_media (user_id, storage_url, media_type)
      values (${seed.userId}, 'https://blob.example.com/quinta.jpg', 'image') returning id
    `;
    fakeRenderAndStoreAutomationArt.mockResolvedValue(renderedMedia.id);
    happyPost({ caption: "Legenda de quinta", cta: "", hashtags: [], visualText: "Frase de quinta" });

    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Automação de quinta-feira",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "AUTO_TEMPLATE",
      fixedImageMediaId: seed.mediaId,
      videoSelection: "FIXED",
      fixedVideoMediaId: seed.videoId,
    });
    await repo.updateAutomationDay(automationId, seed.userId, "THURSDAY" as never, {
      enabled: true,
      contentType: "POST",
      prompt: "Crie uma frase motivacional para quinta-feira, com tom inspirador, humano e simples.",
      publishTime: "07:00",
    });
    await repo.setAutomationStatus(automationId, seed.userId, "ACTIVE");

    // 2026-09-24 é uma quinta-feira — o cron "hoje" bate com o dia
    // configurado, exatamente o cenário de teste manual pedido no
    // briefing (conta @alilu.tec, quinta-feira, 07:00).
    const now = () => new Date("2026-09-24T10:05:00.000Z");
    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("WAITING_APPROVAL");

    const [[callArgs]] = fakeProvider.generatePost.mock.calls;
    expect(callArgs.dayOfWeekLabel).toBe("Quinta-feira");
    expect(callArgs.dayOfWeekLabel).not.toBe("Segunda-feira");
  });

  it("guarda e aplica o véu (overlayOpacity) configurado por dia, e rejeita valores fora dos níveis permitidos", async () => {
    const seed = await seedUserWithAccount(db);
    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Automação com véu customizado",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "AUTO_TEMPLATE",
      fixedImageMediaId: seed.mediaId,
      videoSelection: "FIXED",
      fixedVideoMediaId: seed.videoId,
    });

    await service.updateAutomationDay(automationId, seed.userId, "FRIDAY", {
      enabled: true,
      contentType: "POST",
      contentMode: "MANUAL",
      manualCaption: "Legenda de sexta",
      visualText: "Frase de sexta",
      overlayOpacity: 0.3,
    });

    const details = await service.getAutomationDetails(automationId, seed.userId);
    const friday = details.days.find((day) => day.dayOfWeek === "FRIDAY");
    expect(friday?.overlayOpacity).toBe(0.3);

    await expect(
      service.updateAutomationDay(automationId, seed.userId, "FRIDAY", { overlayOpacity: 0.15 }),
    ).rejects.toThrow(/véu/i);
  });
});

describe("modo CAROUSEL (texto comprido dividido em slides, mesmo motor do Carrossel automático manual)", () => {
  async function activeCarouselAutomation(
    seed: Awaited<ReturnType<typeof seedUserWithAccount>>,
    overrides: {
      contentMode?: "AI" | "MANUAL";
      visualText?: string;
      manualCaption?: string;
      templateId?: string | null;
      visualTextColor?: string | null;
    } = {},
  ) {
    const contentMode = overrides.contentMode ?? "AI";
    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Automação CAROUSEL de teste",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "Marca de utilitários domésticos",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "AUTO_TEMPLATE",
      fixedImageMediaId: seed.mediaId,
      videoSelection: "FIXED",
      fixedVideoMediaId: seed.videoId,
    });

    await repo.updateAutomationDay(automationId, seed.userId, "WEDNESDAY" as never, {
      enabled: true,
      contentType: "CAROUSEL",
      contentMode,
      prompt: contentMode === "AI" ? "Conte a história completa da marca, bem detalhada" : "",
      manualCaption: contentMode === "MANUAL" ? (overrides.manualCaption ?? "Legenda manual completa, com CTA.") : undefined,
      visualText:
        contentMode === "MANUAL"
          ? (overrides.visualText ?? "Um texto longo o bastante para virar vários slides de carrossel, contando uma historinha passo a passo.")
          : undefined,
      templateId: overrides.templateId,
      visualTextColor: overrides.visualTextColor,
      publishTime: "19:00",
    });

    await repo.setAutomationStatus(automationId, seed.userId, "ACTIVE");
    return automationId;
  }

  async function seedRenderedCarouselMedia(seed: Awaited<ReturnType<typeof seedUserWithAccount>>, count: number, prefix = "carousel") {
    const ids: string[] = [];
    for (let i = 0; i < count; i += 1) {
      const [row] = await db.sql`
        insert into instagram_media (user_id, storage_url, media_type)
        values (${seed.userId}, ${`https://blob.example.com/${prefix}-${i}.jpg`}, 'image') returning id
      `;
      ids.push(row.id as string);
    }
    return ids;
  }

  it("modo IA: pede o texto no formato LONG, divide em slides via renderAndStoreAutomationCarousel e cria um post do tipo carrossel", async () => {
    const seed = await seedUserWithAccount(db);
    const mediaIds = await seedRenderedCarouselMedia(seed, 4);
    fakeRenderAndStoreAutomationCarousel.mockResolvedValue({ mediaIds, overflowText: null });
    happyPost({
      caption: "Legenda gerada pela IA para o carrossel",
      cta: "",
      hashtags: [],
      visualText: "Um texto comprido gerado pela IA, que vai ser dividido em vários slides pelo motor do carrossel.",
    });
    await activeCarouselAutomation(seed, { contentMode: "AI", templateId: "promocao" });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("WAITING_APPROVAL");

    expect(fakeProvider.generatePost).toHaveBeenCalledTimes(1);
    const [[callArgs]] = fakeProvider.generatePost.mock.calls;
    expect(callArgs.includeVisualText).toBe(true);
    expect(callArgs.visualTextMode).toBe("LONG");

    expect(fakeRenderAndStoreAutomationCarousel).toHaveBeenCalledTimes(1);
    const [renderArgs] = fakeRenderAndStoreAutomationCarousel.mock.calls[0];
    expect(renderArgs).toMatchObject({
      userId: seed.userId,
      templateId: "promocao",
      sourceImageUrl: "https://blob.example.com/1.jpg",
      sourceMediaId: seed.mediaId,
      visualText: "Um texto comprido gerado pela IA, que vai ser dividido em vários slides pelo motor do carrossel.",
      maxSlides: 10,
    });
    expect(renderArgs.automationRunId).toEqual(expect.any(String));

    const runRow = (await db.sql`select * from automation_runs`)[0];
    const [post] = await db.sql`select * from instagram_posts where id = ${runRow.publication_id}`;
    expect(post.post_type).toBe("carousel");
    expect(post.caption).toBe("Legenda gerada pela IA para o carrossel");
    const items = await db.sql`select media_id, position from instagram_post_items where post_id = ${runRow.publication_id} order by position asc`;
    expect(items.map((item) => item.media_id as string)).toEqual(mediaIds);
  });

  it("modo manual: usa a legenda e o texto longo escritos à mão, sem chamar a IA", async () => {
    const seed = await seedUserWithAccount(db);
    const mediaIds = await seedRenderedCarouselMedia(seed, 3, "manual");
    fakeRenderAndStoreAutomationCarousel.mockResolvedValue({ mediaIds, overflowText: null });
    await activeCarouselAutomation(seed, {
      contentMode: "MANUAL",
      manualCaption: "Legenda manual do carrossel, corre lá!",
      visualText: "Texto manual comprido, escrito à mão, que também vira vários slides.",
      templateId: "frase-motivacional",
      visualTextColor: "#ffcc00",
    });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("WAITING_APPROVAL");
    expect(fakeProvider.generatePost).not.toHaveBeenCalled();

    expect(fakeRenderAndStoreAutomationCarousel).toHaveBeenCalledTimes(1);
    const [renderArgs] = fakeRenderAndStoreAutomationCarousel.mock.calls[0];
    expect(renderArgs).toMatchObject({
      templateId: "frase-motivacional",
      visualText: "Texto manual comprido, escrito à mão, que também vira vários slides.",
      visualTextColor: "#ffcc00",
    });

    const runRow = (await db.sql`select * from automation_runs`)[0];
    const [post] = await db.sql`select * from instagram_posts where id = ${runRow.publication_id}`;
    expect(post.post_type).toBe("carousel");
    expect(post.caption).toBe("Legenda manual do carrossel, corre lá!");
  });

  it("texto que excede o limite de slides é logado como sobra, mas não impede a publicação (o que coube é publicado)", async () => {
    const seed = await seedUserWithAccount(db);
    const mediaIds = await seedRenderedCarouselMedia(seed, 10, "overflow");
    fakeRenderAndStoreAutomationCarousel.mockResolvedValue({ mediaIds, overflowText: "o resto do texto que não coube em 10 slides..." });
    await activeCarouselAutomation(seed, {
      contentMode: "MANUAL",
      manualCaption: "Legenda de um texto gigante",
      visualText: "Texto gigantesco ".repeat(200),
    });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("WAITING_APPROVAL");

    const runRow = (await db.sql`select * from automation_runs`)[0];
    const items = await db.sql`select media_id from instagram_post_items where post_id = ${runRow.publication_id}`;
    expect(items.length).toBe(10);
  });

  it("rejeita (com backoff) quando o texto só dá para menos slides do que o mínimo de um carrossel", async () => {
    const seed = await seedUserWithAccount(db);
    const [onlyMedia] = await seedRenderedCarouselMedia(seed, 1, "curto-demais");
    fakeRenderAndStoreAutomationCarousel.mockResolvedValue({ mediaIds: [onlyMedia], overflowText: null });
    await activeCarouselAutomation(seed, {
      contentMode: "MANUAL",
      manualCaption: "Legenda de um texto curto demais",
      visualText: "Texto curto",
    });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("PENDING");
    expect(result.error).toMatch(/pelo menos 2/);

    const [runRow] = await db.sql`select * from automation_runs`;
    expect(runRow.status).toBe("PENDING");
    expect(runRow.publication_id).toBeNull();
  });

  it("não deixa ativar um dia CAROUSEL quando a automação não usa imageMode AUTO_TEMPLATE", async () => {
    const seed = await seedUserWithAccount(db);
    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Carrossel sem AUTO_TEMPLATE",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "FIXED_IMAGE",
      fixedImageMediaId: seed.mediaId,
      videoSelection: "FIXED",
      fixedVideoMediaId: seed.videoId,
    });
    await repo.updateAutomationDay(automationId, seed.userId, "WEDNESDAY" as never, {
      enabled: true,
      contentType: "CAROUSEL",
      contentMode: "MANUAL",
      manualCaption: "Legenda qualquer",
      visualText: "Texto qualquer",
    });

    await expect(service.activateAutomation(automationId, seed.userId)).rejects.toThrow(/AUTO_TEMPLATE/);
  });

  it("não deixa ativar um dia CAROUSEL manual sem o texto visual, mesmo com legenda preenchida", async () => {
    const seed = await seedUserWithAccount(db);
    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Carrossel incompleto",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "AUTO_TEMPLATE",
      fixedImageMediaId: seed.mediaId,
      videoSelection: "FIXED",
      fixedVideoMediaId: seed.videoId,
    });
    await repo.updateAutomationDay(automationId, seed.userId, "WEDNESDAY" as never, {
      enabled: true,
      contentType: "CAROUSEL",
      contentMode: "MANUAL",
      manualCaption: "Legenda preenchida normalmente.",
      visualText: "",
    });

    await expect(service.activateAutomation(automationId, seed.userId)).rejects.toThrow(/texto.*imagem/i);
  });
});

describe("POST vs. REEL", () => {
  it("dia configurado como REEL usa o vídeo e cria um post do tipo reels", async () => {
    const seed = await seedUserWithAccount(db);
    await activePostAutomation(seed, { contentType: "REEL" });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("WAITING_APPROVAL");
    expect(fakeProvider.generateReel).toHaveBeenCalledTimes(1);
    expect(fakeProvider.generatePost).not.toHaveBeenCalled();

    const runRow = (await db.sql`select * from automation_runs`)[0];
    const [post] = await db.sql`select * from instagram_posts where id = ${runRow.publication_id}`;
    expect(post.post_type).toBe("reels");
  });
});

describe("respeita habilitação, prompt e janela de pré-geração", () => {
  it("não gera nada se o dia de hoje não está habilitado", async () => {
    const seed = await seedUserWithAccount(db);
    await activePostAutomation(seed, { dayOfWeek: "MONDAY" }); // hoje (mock) é quarta
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const results = await cron.runContentAutomationCron({ now });
    expect(results).toEqual([]);
    expect(fakeProvider.generatePost).not.toHaveBeenCalled();
  });

  it("não gera antes da janela de pré-geração (generation_lead_minutes)", async () => {
    const seed = await seedUserWithAccount(db);
    await activePostAutomation(seed, { publishTime: "19:00", generationLeadMinutes: 30 });
    // 3h antes do horário, lead é só 30 min — ainda não é hora.
    const now = () => new Date("2026-09-23T19:00:00.000Z");

    const results = await cron.runContentAutomationCron({ now });
    expect(results).toEqual([]);
    expect(fakeProvider.generatePost).not.toHaveBeenCalled();
  });

  it("automação PAUSADA nunca é considerada pelo cron", async () => {
    const seed = await seedUserWithAccount(db);
    const id = await activePostAutomation(seed);
    await service.pauseAutomation(id, seed.userId, { cancelScheduledRuns: false });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const results = await cron.runContentAutomationCron({ now });
    expect(results).toEqual([]);
  });
});

describe("multi-conta e multi-automação: nunca cruza dados", () => {
  it("duas automações de dois usuários/contas diferentes, mesmo dia e horário, geram publicações isoladas", async () => {
    const a = await seedUserWithAccount(db, "a");
    const b = await seedUserWithAccount(db, "b");
    await activePostAutomation(a, { publishTime: "19:00" });
    await activePostAutomation(b, { publishTime: "19:00" });
    fakeProvider.generatePost
      .mockResolvedValueOnce({
        content: { title: "A", caption: "Legenda de A", hashtags: [], cta: "", visualDescription: "" },
        usage: { provider: "anthropic", model: "claude-test", tokensInput: 1, tokensOutput: 1 },
      })
      .mockResolvedValueOnce({
        content: { title: "B", caption: "Legenda de B", hashtags: [], cta: "", visualDescription: "" },
        usage: { provider: "anthropic", model: "claude-test", tokensInput: 1, tokensOutput: 1 },
      });
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const results = await cron.runContentAutomationCron({ now });
    expect(results).toHaveLength(2);

    const posts = await db.sql`select user_id, instagram_account_id, caption from instagram_posts order by caption`;
    expect(posts).toHaveLength(2);
    expect(posts[0].user_id).not.toBe(posts[1].user_id);
    expect(posts.map((p) => p.caption).sort()).toEqual(
      ["Legenda de A\n\nLegenda de A".slice(0, 0) || posts[0].caption, posts[1].caption].sort(),
    );
    // Cada publicação pertence à conta certa (nunca mistura conta A com usuário B).
    for (const post of posts) {
      const [account] = await db.sql`select user_id from instagram_accounts where id = ${post.instagram_account_id}`;
      expect(account.user_id).toBe(post.user_id);
    }
  });

  it("duas automações do MESMO usuário (contas diferentes) mantêm runs e posts separados", async () => {
    const seed = await seedUserWithAccount(db, "multi");
    const [secondAccount] = await db.sql`
      insert into instagram_accounts (user_id, ig_user_id, ig_username, access_token_encrypted)
      values (${seed.userId}, 'ig-multi-2', 'conta2', 'cifrado') returning id
    `;
    const [secondMedia] = await db.sql`
      insert into instagram_media (user_id, storage_url, media_type)
      values (${seed.userId}, 'https://blob.example.com/segunda.jpg', 'image') returning id
    `;

    const firstAutomationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Conta 1",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "FIXED_IMAGE",
      fixedImageMediaId: seed.mediaId,
      videoSelection: "FIXED",
      fixedVideoMediaId: null,
    });
    await repo.updateAutomationDay(firstAutomationId, seed.userId, "WEDNESDAY", {
      enabled: true,
      contentType: "POST",
      prompt: "Prompt da conta 1",
      publishTime: "19:00",
    });
    await repo.setAutomationStatus(firstAutomationId, seed.userId, "ACTIVE");

    const secondAutomationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: secondAccount.id as string,
      name: "Conta 2",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "FIXED_IMAGE",
      fixedImageMediaId: secondMedia.id as string,
      videoSelection: "FIXED",
      fixedVideoMediaId: null,
    });
    await repo.updateAutomationDay(secondAutomationId, seed.userId, "WEDNESDAY", {
      enabled: true,
      contentType: "POST",
      prompt: "Prompt da conta 2",
      publishTime: "19:00",
    });
    await repo.setAutomationStatus(secondAutomationId, seed.userId, "ACTIVE");

    const now = () => new Date("2026-09-23T20:00:00.000Z");
    const results = await cron.runContentAutomationCron({ now });
    expect(results).toHaveLength(2);

    const runs = await db.sql`select automation_id, instagram_account_id from automation_runs order by automation_id`;
    expect(runs).toHaveLength(2);
    expect(new Set(runs.map((r) => r.instagram_account_id)).size).toBe(2);
  });
});

describe("posse (ownership) entre usuários", () => {
  it("usuário B não vê, edita, ativa, aprova nem exclui a automação de A", async () => {
    const a = await seedUserWithAccount(db, "a");
    const b = await seedUserWithAccount(db, "b");
    const automationId = await activePostAutomation(a);

    await expect(service.getAutomationDetails(automationId, b.userId)).rejects.toThrow("Automação não encontrada.");
    await expect(service.updateAutomation(automationId, b.userId, { name: "invasão" })).rejects.toThrow();
    await expect(service.updateAutomationDay(automationId, b.userId, "WEDNESDAY", { enabled: false })).rejects.toThrow();
    await expect(service.pauseAutomation(automationId, b.userId, { cancelScheduledRuns: false })).rejects.toThrow();
    await expect(service.deleteAutomation(automationId, b.userId)).rejects.toThrow();
    await expect(service.duplicateAutomation(automationId, b.userId)).rejects.toThrow();

    const [row] = await db.sql`select status, name from content_automations where id = ${automationId}`;
    expect(row.status).toBe("ACTIVE");
    expect(row.name).toBe("Automação de teste");
  });

  it("usuário B não usa mídia de A ao criar/editar sua própria automação", async () => {
    const a = await seedUserWithAccount(db, "a");
    const b = await seedUserWithAccount(db, "b");

    await expect(
      service.createAutomation({
        userId: b.userId,
        instagramAccountId: b.accountId,
        name: "Tenta usar mídia de A",
        fixedImageMediaId: a.mediaId,
      }),
    ).rejects.toThrow();
  });

  it("usuário B não aprova nem rejeita execução (run) de A", async () => {
    const a = await seedUserWithAccount(db, "a");
    const b = await seedUserWithAccount(db, "b");
    await activePostAutomation(a);
    const now = () => new Date("2026-09-23T20:00:00.000Z");
    await cron.runContentAutomationCron({ now });
    const runRow = (await db.sql`select * from automation_runs`)[0];

    await expect(service.approveAutomationRun(runRow.id as string, b.userId)).rejects.toThrow("Execução não encontrada.");
    await expect(service.rejectAutomationRun(runRow.id as string, b.userId)).rejects.toThrow("Execução não encontrada.");
  });
});

describe("ativação exige configuração completa", () => {
  it("não deixa ativar sem nenhum dia habilitado", async () => {
    const seed = await seedUserWithAccount(db);
    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Vazia",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "FIXED_IMAGE",
      fixedImageMediaId: null,
      videoSelection: "FIXED",
      fixedVideoMediaId: null,
    });
    await expect(service.activateAutomation(automationId, seed.userId)).rejects.toThrow(
      "Habilite pelo menos um dia da semana antes de ativar.",
    );
  });

  it("não deixa ativar um dia habilitado como POST sem imagem resolvível", async () => {
    const seed = await seedUserWithAccount(db);
    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Sem imagem",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "FIXED_IMAGE",
      fixedImageMediaId: null,
      videoSelection: "FIXED",
      fixedVideoMediaId: null,
    });
    await repo.updateAutomationDay(automationId, seed.userId, "WEDNESDAY", {
      enabled: true,
      contentType: "POST",
      prompt: "Algo",
      publishTime: "19:00",
    });
    await expect(service.activateAutomation(automationId, seed.userId)).rejects.toThrow(/imagem/);
  });

  it("aceita imageMode AUTO_TEMPLATE (implementado nesta etapa), mas ainda rejeita videoSelection ROTATE/RANDOM", async () => {
    const seed = await seedUserWithAccount(db);
    // AUTO_TEMPLATE agora é um imageMode suportado — a validação de
    // mídia/texto visual acontece só na ativação (ver
    // "não deixa ativar" nos testes de AUTO_TEMPLATE acima), não na criação.
    await expect(
      service.createAutomation({
        userId: seed.userId,
        instagramAccountId: seed.accountId,
        name: "Template automático",
        imageMode: "AUTO_TEMPLATE",
      }),
    ).resolves.toEqual(expect.any(String));

    await expect(
      service.createAutomation({
        userId: seed.userId,
        instagramAccountId: seed.accountId,
        name: "Rotação de vídeo",
        videoSelection: "ROTATE",
      }),
    ).rejects.toThrow(/Vídeo fixo/);
  });
});

describe("cancelamento ao pausar", () => {
  it("pausar com 'cancelar futuras' cancela runs pendentes/aguardando aprovação", async () => {
    const seed = await seedUserWithAccount(db);
    const automationId = await activePostAutomation(seed, { requireApproval: true });
    const now = () => new Date("2026-09-23T20:00:00.000Z");
    await cron.runContentAutomationCron({ now });

    const before = (await db.sql`select status from automation_runs`)[0];
    expect(before.status).toBe("WAITING_APPROVAL");

    await service.pauseAutomation(automationId, seed.userId, { cancelScheduledRuns: true });

    const after = (await db.sql`select status from automation_runs`)[0];
    expect(after.status).toBe("CANCELLED");
  });
});

describe("retentativa de geração com falha", () => {
  it("erro na geração aplica backoff de 5 minutos e não derruba o cron para outras automações", async () => {
    const seed = await seedUserWithAccount(db);
    await activePostAutomation(seed);
    fakeProvider.generatePost.mockRejectedValueOnce(new Error("Falha simulada do provedor de IA"));
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("PENDING");
    expect(result.error).toMatch(/Falha simulada/);

    const [runRow] = await db.sql`select * from automation_runs`;
    expect(runRow.status).toBe("PENDING");
    expect(runRow.generation_attempt).toBe(1);
    expect(runRow.next_attempt_at).not.toBeNull();

    // O backoff calculado usa o `now` injetado (fixo em 2026-09-23), mas a
    // elegibilidade do claim compara com o relógio REAL do Postgres (ver
    // comentário do teste seguinte) — então força next_attempt_at para o
    // futuro relativo ao relógio real, em vez de depender da data fixa do
    // teste continuar no futuro conforme o tempo passa.
    await db.sql`update automation_runs set next_attempt_at = now() + interval '1 hour'`;

    // Antes do backoff acabar, uma nova chamada não tenta de novo.
    expect(await cron.runContentAutomationCron({ now })).toEqual([]);
    expect(fakeProvider.generatePost).toHaveBeenCalledTimes(1);
  });

  it("depois de esgotar as tentativas, a execução fica FAILED definitivamente", async () => {
    // A elegibilidade do claim (`next_attempt_at <= now()`) é avaliada pelo
    // relógio REAL do Postgres, não pelo `now` injetado no cron (que só
    // controla a janela de pré-geração e o cálculo do próximo backoff) —
    // mesmo padrão usado em instagram-scheduler.test.ts: força o
    // next_attempt_at para o passado via SQL em vez de simular o tempo.
    const seed = await seedUserWithAccount(db);
    await activePostAutomation(seed);
    fakeProvider.generatePost.mockRejectedValue(new Error("Sempre falha"));
    const now = () => new Date("2026-09-23T20:00:00.000Z");

    for (let attempt = 1; attempt <= 3; attempt += 1) {
      await cron.runContentAutomationCron({ now });
      await db.sql`update automation_runs set next_attempt_at = now() - interval '1 second'`;
    }
    const results = await cron.runContentAutomationCron({ now }); // 4ª tentativa -> FAILED definitivo

    expect(results[0].status).toBe("FAILED");
    const [runRow] = await db.sql`select * from automation_runs`;
    expect(runRow.status).toBe("FAILED");
    expect(runRow.generation_attempt).toBe(4);
    expect(runRow.next_attempt_at).toBeNull();
  });
});

describe("configuração incompleta é bloqueada mesmo dentro do cron (defesa em profundidade)", () => {
  it("dia REEL sem vídeo configurado falha com erro claro em vez de publicar algo quebrado", async () => {
    const seed = await seedUserWithAccount(db);
    const automationId = await repo.createAutomation({
      userId: seed.userId,
      instagramAccountId: seed.accountId,
      name: "Reel sem vídeo",
      description: "",
      timezone: "America/Sao_Paulo",
      brandContext: "",
      autoPublish: false,
      requireApproval: true,
      generationLeadMinutes: 120,
      imageMode: "FIXED_IMAGE",
      fixedImageMediaId: null,
      videoSelection: "FIXED",
      fixedVideoMediaId: null,
    });
    // Contorna a validação da service para simular um dado antigo/inconsistente direto no repo.
    await repo.updateAutomationDay(automationId, seed.userId, "WEDNESDAY", {
      enabled: true,
      contentType: "REEL",
      prompt: "Reel sem vídeo",
      publishTime: "19:00",
    });
    await repo.setAutomationStatus(automationId, seed.userId, "ACTIVE");

    const now = () => new Date("2026-09-23T20:00:00.000Z");
    const [result] = await cron.runContentAutomationCron({ now });
    expect(result.status).toBe("PENDING");
    expect(result.error).toMatch(/[Nn]enhum vídeo configurado/);
    expect(fakeProvider.generateReel).not.toHaveBeenCalled();
  });
});

describe("autorização do endpoint do cron", () => {
  afterEach(() => {
    delete process.env.CONTENT_AUTOMATION_CRON_SECRET;
    delete process.env.CRON_SECRET;
    delete process.env.INSTAGRAM_SCHEDULER_SECRET;
  });

  it("aceita CONTENT_AUTOMATION_CRON_SECRET dedicado ou os segredos já existentes do agendador", () => {
    process.env.CONTENT_AUTOMATION_CRON_SECRET = "segredo-dedicado-com-mais-de-16";
    const ok = new Request("https://x/api/cron/content-automation", {
      headers: { authorization: "Bearer segredo-dedicado-com-mais-de-16" },
    });
    expect(cron.isContentAutomationCronRequestAuthorized(ok)).toBe(true);

    delete process.env.CONTENT_AUTOMATION_CRON_SECRET;
    process.env.CRON_SECRET = "segredo-do-agendador-existente-16";
    const okShared = new Request("https://x/api/cron/content-automation", {
      headers: { authorization: "Bearer segredo-do-agendador-existente-16" },
    });
    expect(cron.isContentAutomationCronRequestAuthorized(okShared)).toBe(true);
  });

  it("nunca aceita segredo ausente, curto ou incorreto", () => {
    process.env.CRON_SECRET = "segredo-do-agendador-existente-16";
    const wrong = new Request("https://x/api/cron/content-automation", { headers: { authorization: "Bearer errado" } });
    const none = new Request("https://x/api/cron/content-automation");
    expect(cron.isContentAutomationCronRequestAuthorized(wrong)).toBe(false);
    expect(cron.isContentAutomationCronRequestAuthorized(none)).toBe(false);
  });
});

describe("nunca duplica a camada de publicação", () => {
  it("createDraftImagePost/createDraftReelPost usadas pelo cron são exatamente as do módulo de publicação existente", async () => {
    // Prova estrutural: o cron importa as mesmas funções exportadas por
    // instagram-post-repository.ts — não existe uma segunda implementação
    // de "criar publicação" dentro de content-automation.
    const path = await import("node:path");
    const fs = await import("node:fs/promises");
    const cronSource = await fs.readFile(
      path.join(process.cwd(), "lib/content-automation/backend/content-automation-cron.ts"),
      "utf-8",
    );
    expect(cronSource).toContain('from "@/lib/instagram/backend/instagram-post-repository"');
    expect(cronSource).toContain("createDraftImagePost");
    expect(cronSource).toContain("createDraftReelPost");
    expect(cronSource).not.toMatch(/publishMediaContainer|meta-graph-client/);
    // Mesmo padrão de claim atômico do agendador existente (lock com TTL) — não uma técnica nova.
    expect(runRepo.RUN_LOCK_TTL_SECONDS).toBeGreaterThan(0);
    void postRepo; // referenciado só para garantir que o módulo real existe/compila.
  });
});
